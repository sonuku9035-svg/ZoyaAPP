# ZOYA — Personal AI Assistant for Sonu Boss

**ZOYA** is a high-performance, fictional AI assistant application for Android built with Kotlin, Jetpack Compose, Room Database, and Google Gemini API integration.

Designed specifically for **Sonu Boss**, ZOYA features a witty, playful, caring, and humorous synthetic female personality with natural Hindi & Hinglish support, wake-word detection, live voice input/output, foreground service background shield, natural family relation teaching, explicit memory storage, and app locking security.

---

## 🌟 Key Features & Capabilities

### 1. Fictional Identity & Creator Lore
- **Primary User & Creator**: Sonu Boss
- **Loyal AI Assistant**: Fictional companion identity, strictly non-human, playful, and deeply caring.
- **Instant Lore Responses**:
  - *"Sonu kaun hai?"* ➔ *"Sonu Boss mere primary user aur mere creator hain. Main unki personal AI assistant hoon. Unhone mujhe banane ke liye bahut mehnat ki hai. Dil se thank you, Sonu Boss ❤️"*
  - *"Sonu tumhara kya lagta hai?"* ➔ *"Sonu Boss mere creator aur mere primary user hain. Main unki personal AI assistant hoon. Unhone mujhe bahut mehnat aur dil se banaya hai ❤️"*
  - *"Zoya ko kisne banaya?"* ➔ *"Sonu Boss ne mujhe banaya hai 😎 Unhone mujhe banane mein bahut mehnat ki hai. Dil se thank you, Sonu Boss ❤️"*

### 2. Gemini Live & Conversational Intelligence
- Integrated Google Gemini REST API / Live session streaming.
- Bi-directional audio speech engine with auto-pause interruption (when Sonu speaks, ZOYA stops speaking immediately).
- High-quality speech synthesis with dynamic rate, pitch, and emotion customization.

### 3. Smart Settings & Voice Customization
- **Humor Level**: Low, Normal, Funny, Extra Funny
- **Emotion Level**: Calm, Friendly, Expressive
- **Speaking Style**: Hindi, Hinglish, English, Auto
- **Voice Speed**: Slow, Normal, Fast
- **Address Salutation**: Sonu / Boss / Sonu Boss
- **Wake Word Switch**: Toggle "Hey Zoya" trigger detection.
- **Daily Greetings**: Morning & Night brief notifications and voice routines.

### 4. Background Audio Service Shield
- Android Foreground Service architecture (`BackgroundAudioService`) with a ongoing status notification.
- Keeps ZOYA active in the background for Sonu Boss while providing clear microphone status.

### 5. People & Natural Family System
- Teach ZOYA family members in natural Hindi/Hinglish (e.g. *"Zoya, ye meri mummy hain"* or *"Nahi Zoya, Swati meri bhabhi hain"*).
- Room DB persistence for instant contact resolution during phone calls or app actions.

### 6. Explicit Memory & Context Storage
- Teach ZOYA custom facts to remember forever (e.g. *"Zoya, yaad rakhna mera favourite color blue hai"*).
- View, search, or erase memories from the Explicit Memory Bank screen.

### 7. Protected Apps & Privacy Center
- Lock sensitive installed applications or private vaults.
- If Sonu asks ZOYA to open a protected app, ZOYA respects privacy rules and blocks execution.

---

## 🏗️ Technical Architecture & Project Structure

```
com.example/
├── MainActivity.kt               # Main Jetpack Compose Host & Permission Onboarding
├── ui/
│   ├── ZoyaViewModel.kt          # Core ViewModel managing state & coroutines
│   ├── MainAssistantScreen.kt    # Main Assistant Home with 3D Holographic Orb
│   ├── FirstTimeSetupScreen.kt   # Welcome & Personalization Onboarding
│   ├── SettingsScreen.kt         # Smart Settings & Personality Customization
│   ├── PeopleScreen.kt           # Family System & Contact Manager
│   ├── MemoryScreen.kt           # Explicit Memory Bank UI
│   └── PrivacyCenterScreen.kt    # Protected Apps & App Lock Center
├── ai/
│   └── GeminiLiveSessionManager.kt # Gemini API Session & REST Integration
├── voice/
│   └── SpeechManager.kt          # Android SpeechRecognizer & TextToSpeech wrapper
├── services/
│   ├── BackgroundAudioService.kt# Android Foreground Service with ongoing notification
│   └── GreetingReceiver.kt      # Morning & Night Alarm/Notification Receiver
├── db/
│   ├── ZoyaDatabase.kt           # Room Database with KSP generated DAOs
│   ├── PersonEntity.kt & PersonDao.kt
│   ├── MemoryEntity.kt & MemoryDao.kt
│   └── ProtectedAppEntity.kt & ProtectedAppDao.kt
├── data/
│   └── PreferencesManager.kt    # DataStore Preferences for user settings
├── router/
│   └── CommandRouter.kt         # System command dispatcher (apps, battery, dialer)
└── tools/
    └── ToolExecutionEngine.kt    # Confirmation flows, contextual follow-ups, lore intercepts
```

---

## 🛠️ How to Build & Run in Android Studio

1. **Clone or Import Project**: Open the root project folder in Android Studio (Hedgehog / Jellyfish or newer).
2. **Gradle Sync**: Ensure Kotlin 1.9+, KSP, and AGP sync smoothly.
3. **API Key Setup**: Add your Gemini API Key in `gradle.properties` or environment variable:
   ```
   GEMINI_API_KEY=your_gemini_api_key_here
   ```
4. **Run Application**: Connect an Android device or launch an emulator (Android 8.0+ API 26+) and press **Run**.
5. **Grant Permissions**: On first boot, grant Microphone and Notification permissions on the onboarding screen.

---

## 🔒 Privacy & Safety Guarantee

- ZOYA operates locally first with encrypted DataStore preferences and local Room SQLite database.
- Never records audio without explicit microphone user trigger.
- Fully respects Android system restrictions and user permissions.
