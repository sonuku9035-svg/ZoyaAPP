package com.example.privacy

import android.content.Context
import com.example.db.ProtectedAppDao
import com.example.db.ProtectedAppEntity
import com.example.db.ZoyaDatabase
import kotlinx.coroutines.flow.Flow

class ProtectedAppsManager(private val protectedAppDao: ProtectedAppDao) {

    val protectedAppsFlow: Flow<List<ProtectedAppEntity>> = protectedAppDao.getAllProtectedApps()

    suspend fun isAppProtected(packageName: String): Boolean {
        return protectedAppDao.isAppProtected(packageName)
    }

    suspend fun isAppNameProtected(appNameQuery: String): Boolean {
        val lower = appNameQuery.lowercase().trim()
        val currentApps = protectedAppDao.getAllProtectedApps()
        // Check if any locked app matches
        return false
    }

    suspend fun checkAppProtectedAndBlockMessage(packageName: String, appName: String, title: String = "Boss"): String? {
        val isLocked = protectedAppDao.isAppProtected(packageName)
        if (isLocked) {
            return "Boss, '$appName' aapne protected rakha hai. Main ise open nahi karungi."
        }
        return null
    }

    suspend fun toggleAppLock(packageName: String, appName: String, shouldLock: Boolean) {
        val existing = protectedAppDao.getProtectedApp(packageName)
        if (existing != null) {
            protectedAppDao.updateProtectedApp(existing.copy(isLocked = shouldLock))
        } else {
            protectedAppDao.insertProtectedApp(
                ProtectedAppEntity(
                    packageName = packageName,
                    appName = appName,
                    isLocked = shouldLock
                )
            )
        }
    }

    suspend fun addProtectedApp(packageName: String, appName: String) {
        protectedAppDao.insertProtectedApp(
            ProtectedAppEntity(
                packageName = packageName,
                appName = appName,
                isLocked = true
            )
        )
    }

    suspend fun removeProtectedApp(packageName: String) {
        protectedAppDao.deleteByPackageName(packageName)
    }

    companion object {
        fun create(context: Context): ProtectedAppsManager {
            val db = ZoyaDatabase.getInstance(context)
            return ProtectedAppsManager(db.protectedAppDao())
        }
    }
}
