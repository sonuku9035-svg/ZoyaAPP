package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ZoyaState
import com.example.ui.theme.ZoyaCrimson
import com.example.ui.theme.ZoyaCyanSecondary
import com.example.ui.theme.ZoyaElectricBlue
import com.example.ui.theme.ZoyaPinkTertiary
import com.example.ui.theme.ZoyaVioletPrimary

/**
 * Renders the state badge, live waveforms, and active vocal subtitles for Zoya.
 */
@Composable
fun VoiceStatus(
    state: ZoyaState,
    isMuted: Boolean,
    userName: String,
    preferredTitle: String,
    liveTranscript: String,
    lastSpokenText: String,
    rmsAudioLevel: Float,
    modifier: Modifier = Modifier
) {
    val statusText = when {
        isMuted -> "MUTED"
        state == ZoyaState.LISTENING -> "LISTENING..."
        state == ZoyaState.THINKING -> "THINKING..."
        state == ZoyaState.SPEAKING -> "SPEAKING..."
        state == ZoyaState.WORKING -> "WORKING..."
        else -> "READY, ${userName.uppercase()} ${preferredTitle.uppercase()}"
    }

    val statusColor = when {
        isMuted -> ZoyaCrimson
        state == ZoyaState.LISTENING -> ZoyaPinkTertiary
        state == ZoyaState.THINKING -> ZoyaElectricBlue
        state == ZoyaState.SPEAKING -> ZoyaCyanSecondary
        state == ZoyaState.WORKING -> ZoyaVioletPrimary
        else -> ZoyaCyanSecondary
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.fillMaxWidth()
    ) {
        // User Title Header (Sonu Boss)
        Text(
            text = "$userName $preferredTitle",
            style = MaterialTheme.typography.headlineSmall.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = Color.White
            ),
            modifier = Modifier.testTag("user_boss_label")
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Dynamic Status Badge
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(statusColor.copy(alpha = 0.15f))
                .border(1.dp, statusColor.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .testTag("main_status_badge")
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(statusColor)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = statusText,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.5.sp,
                    color = statusColor
                )
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Dynamic Waveform indicator during active speech recognition
        if (state == ZoyaState.LISTENING && !isMuted) {
            Row(
                modifier = Modifier.padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val heights = listOf(
                    (12 + rmsAudioLevel * 20).coerceIn(8f, 32f),
                    (18 + rmsAudioLevel * 30).coerceIn(10f, 42f),
                    (26 + rmsAudioLevel * 45).coerceIn(14f, 52f),
                    (18 + rmsAudioLevel * 30).coerceIn(10f, 42f),
                    (12 + rmsAudioLevel * 20).coerceIn(8f, 32f)
                )
                heights.forEach { h ->
                    Box(
                        modifier = Modifier
                            .width(6.dp)
                            .height(h.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(ZoyaPinkTertiary)
                    )
                }
            }
        }

        // Subtitle / Live voice transcription
        if (state == ZoyaState.LISTENING && liveTranscript.isNotBlank()) {
            Text(
                text = "\"$liveTranscript\"",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = ZoyaCyanSecondary,
                    fontWeight = FontWeight.SemiBold
                ),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        } else if (state == ZoyaState.SPEAKING && lastSpokenText.isNotBlank()) {
            Text(
                text = "\"$lastSpokenText\"",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color.LightGray
                ),
                textAlign = TextAlign.Center,
                maxLines = 3,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )
        } else if (isMuted) {
            Text(
                text = "Voice audio is muted. Tap UNMUTE or Microphone to speak.",
                style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray),
                textAlign = TextAlign.Center
            )
        } else {
            Text(
                text = "Tap the microphone or orb to talk with Zoya",
                style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray),
                textAlign = TextAlign.Center
            )
        }
    }
}
