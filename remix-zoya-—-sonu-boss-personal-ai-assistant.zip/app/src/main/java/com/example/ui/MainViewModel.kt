package com.example.ui

/**
 * MainViewModel typealias for ZoyaViewModel adhering to MVVM / Clean Architecture.
 */
typealias MainViewModel = ZoyaViewModel
