package com.example.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

/**
 * Clean entry point Composable for the Main Voice Assistant screen.
 */
@Composable
fun MainScreen(
    viewModel: MainViewModel,
    onNavigateToSettings: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    MainAssistantScreen(
        viewModel = viewModel,
        onNavigateToSettings = onNavigateToSettings,
        modifier = modifier
    )
}
