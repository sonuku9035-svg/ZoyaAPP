package com.example.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.UserPreferences
import com.example.model.ChatMessage
import com.example.model.MessageSender
import com.example.model.ZoyaPersonality
import com.example.model.ZoyaState
import com.example.ui.theme.ZoyaCyanSecondary
import com.example.ui.theme.ZoyaDarkBackground
import com.example.ui.theme.ZoyaDarkCard
import com.example.ui.theme.ZoyaDarkSurface
import com.example.ui.theme.ZoyaPinkTertiary
import com.example.ui.theme.ZoyaVioletPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ZoyaHomeScreen(
    viewModel: ZoyaViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val zoyaState by viewModel.currentState.collectAsState()
    val preferences by viewModel.userPreferences.collectAsState()
    val messages by viewModel.messages.collectAsState()

    var textInput by remember { mutableStateOf("") }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showPersonalityDialog by remember { mutableStateOf(false) }
    var showMicRationaleDialog by remember { mutableStateOf(false) }

    val micLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startListening()
        } else {
            showMicRationaleDialog = true
        }
    }

    val onMicAction = {
        when (zoyaState) {
            ZoyaState.SPEAKING -> viewModel.stopSpeaking()
            ZoyaState.LISTENING -> viewModel.stopListeningAndProcess()
            else -> {
                val hasPerm = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED

                if (hasPerm) {
                    viewModel.startListening()
                } else {
                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
        }
    }

    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "ZOYA Assistant",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Text(
                            text = "${preferences.userName} ${preferences.preferredTitle}'s AI",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = ZoyaCyanSecondary
                            )
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showPersonalityDialog = true },
                        modifier = Modifier.testTag("personality_prompt_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = "View System Prompt",
                            tint = ZoyaCyanSecondary
                        )
                    }
                    IconButton(
                        onClick = { showSettingsDialog = true },
                        modifier = Modifier.testTag("settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ZoyaDarkSurface
                )
            )
        },
        containerColor = ZoyaDarkBackground,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Orb / AI Visualizer
            ZoyaOrbVisualizer(
                state = zoyaState,
                userName = preferences.userName,
                title = preferences.preferredTitle,
                onMicClick = onMicAction
            )

            // Conversation feed
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    ChatMessageBubble(
                        message = msg,
                        onSpeak = { viewModel.speakText(it) }
                    )
                }
            }

            // Quick Prompt Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val chips = listOf(
                    "Hey Zoya!",
                    "Tell me a joke, Boss",
                    "System status check",
                    "Who are you?",
                    "Good morning Zoya"
                )
                items(chips) { prompt ->
                    FilterChip(
                        selected = false,
                        onClick = { viewModel.sendMessage(prompt) },
                        label = { Text(prompt, color = Color.White, fontSize = 12.sp) },
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = false,
                            borderColor = ZoyaVioletPrimary.copy(alpha = 0.5f)
                        )
                    )
                }
            }

            // Bottom Input Bar
            Surface(
                color = ZoyaDarkSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onMicAction,
                        modifier = Modifier
                            .testTag("mic_toggle_button")
                            .clip(CircleShape)
                            .background(
                                if (zoyaState == ZoyaState.LISTENING) ZoyaPinkTertiary else ZoyaVioletPrimary
                            )
                    ) {
                        Icon(
                            imageVector = if (zoyaState == ZoyaState.LISTENING) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = "Microphone",
                            tint = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = { Text("Ask Zoya anything, Boss...", color = Color.Gray) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("message_input_field"),
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ZoyaVioletPrimary,
                            unfocusedBorderColor = Color.DarkGray,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            if (textInput.isNotBlank()) {
                                viewModel.sendMessage(textInput)
                                textInput = ""
                            }
                        },
                        modifier = Modifier
                            .testTag("send_button")
                            .clip(CircleShape)
                            .background(ZoyaCyanSecondary)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = Color.Black
                        )
                    }
                }
            }
        }
    }

    if (showMicRationaleDialog) {
        AlertDialog(
            onDismissRequest = { showMicRationaleDialog = false },
            title = { Text("Microphone Permission Required", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Sonu ${preferences.preferredTitle}, ZOYA needs Microphone permission to hear your voice commands. Please allow microphone access.",
                    color = Color.LightGray
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showMicRationaleDialog = false
                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }) {
                    Text("Grant Permission", color = ZoyaCyanSecondary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showMicRationaleDialog = false
                    try {
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.fromParts("package", context.packageName, null)
                        }
                        context.startActivity(intent)
                    } catch (_: Exception) {}
                }) {
                    Text("Settings", color = Color.Gray)
                }
            },
            containerColor = ZoyaDarkSurface
        )
    }

    if (showSettingsDialog) {
        ZoyaSettingsDialog(
            preferences = preferences,
            onDismiss = { showSettingsDialog = false },
            onUpdateName = { viewModel.updateUserName(it) },
            onUpdateTitle = { viewModel.updatePreferredTitle(it) },
            onToggleWakeWord = { viewModel.toggleWakeWord(it) },
            onToggleMorning = { viewModel.toggleMorningGreeting(it) },
            onToggleNight = { viewModel.toggleNightGreeting(it) }
        )
    }

    if (showPersonalityDialog) {
        ZoyaPersonalityDialog(
            userName = preferences.userName,
            title = preferences.preferredTitle,
            onDismiss = { showPersonalityDialog = false }
        )
    }
}

@Composable
fun ZoyaOrbVisualizer(
    state: ZoyaState,
    userName: String,
    title: String,
    onMicClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "OrbPulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "OrbScale"
    )

    val orbGradient = when (state) {
        ZoyaState.IDLE -> Brush.radialGradient(
            colors = listOf(ZoyaVioletPrimary, ZoyaDarkSurface)
        )
        ZoyaState.LISTENING -> Brush.radialGradient(
            colors = listOf(ZoyaPinkTertiary, ZoyaVioletPrimary)
        )
        ZoyaState.THINKING, ZoyaState.WORKING -> Brush.radialGradient(
            colors = listOf(ZoyaCyanSecondary, ZoyaVioletPrimary)
        )
        ZoyaState.SPEAKING -> Brush.radialGradient(
            colors = listOf(ZoyaCyanSecondary, ZoyaPinkTertiary, ZoyaVioletPrimary)
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("zoya_orb_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = ZoyaDarkCard)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(80.dp)
                    .scale(if (state != ZoyaState.IDLE) scale else 1.0f)
                    .clip(CircleShape)
                    .background(orbGradient)
                    .border(2.dp, ZoyaCyanSecondary, CircleShape)
                    .clickable { onMicClick() }
                    .testTag("zoya_orb_button")
            ) {
                Icon(
                    imageVector = Icons.Default.SmartToy,
                    contentDescription = "ZOYA Orb",
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "ZOYA STATUS",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = ZoyaCyanSecondary,
                        letterSpacing = 1.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = state.statusMessage,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier.testTag("zoya_status_text")
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Personal Assistant to $userName $title",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color.LightGray)
                )
            }
        }
    }
}

@Composable
fun ChatMessageBubble(
    message: ChatMessage,
    onSpeak: ((String) -> Unit)? = null
) {
    val isUser = message.sender == MessageSender.USER
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom
    ) {
        if (!isUser) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(ZoyaVioletPrimary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.SmartToy,
                    contentDescription = "ZOYA",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            color = if (isUser) ZoyaVioletPrimary else ZoyaDarkCard,
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = message.text,
                    color = Color.White,
                    fontSize = 14.sp,
                    modifier = Modifier.weight(1f, fill = false)
                )

                if (!isUser && onSpeak != null) {
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = { onSpeak(message.text) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Hear Zoya Speak",
                            tint = ZoyaCyanSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ZoyaSettingsDialog(
    preferences: UserPreferences,
    onDismiss: () -> Unit,
    onUpdateName: (String) -> Unit,
    onUpdateTitle: (String) -> Unit,
    onToggleWakeWord: (Boolean) -> Unit,
    onToggleMorning: (Boolean) -> Unit,
    onToggleNight: (Boolean) -> Unit
) {
    var tempName by remember { mutableStateOf(preferences.userName) }
    var tempTitle by remember { mutableStateOf(preferences.preferredTitle) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ZOYA Settings", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = tempName,
                    onValueChange = { tempName = it },
                    label = { Text("User Name") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                OutlinedTextField(
                    value = tempTitle,
                    onValueChange = { tempTitle = it },
                    label = { Text("Preferred Title (e.g. Boss)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Wake Word (\"Hey Zoya\")", color = Color.White)
                    Switch(
                        checked = preferences.wakeWordEnabled,
                        onCheckedChange = onToggleWakeWord
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Morning Greeting", color = Color.White)
                    Switch(
                        checked = preferences.morningGreetingEnabled,
                        onCheckedChange = onToggleMorning
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Night Greeting", color = Color.White)
                    Switch(
                        checked = preferences.nightGreetingEnabled,
                        onCheckedChange = onToggleNight
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onUpdateName(tempName.ifBlank { "Sonu" })
                onUpdateTitle(tempTitle.ifBlank { "Boss" })
                onDismiss()
            }) {
                Text("Save", color = ZoyaCyanSecondary)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color.Gray)
            }
        },
        containerColor = ZoyaDarkSurface
    )
}

@Composable
fun ZoyaPersonalityDialog(
    userName: String,
    title: String,
    onDismiss: () -> Unit
) {
    val prompt = remember(userName, title) {
        ZoyaPersonality.getDynamicSystemPrompt(userName, title)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("ZOYA Personality Prompt Engine", color = Color.White, fontWeight = FontWeight.Bold)
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .background(ZoyaDarkCard, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                item {
                    Text(
                        text = prompt,
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = ZoyaCyanSecondary)
            }
        },
        containerColor = ZoyaDarkSurface
    )
}
