package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.ZoyaState
import com.example.ui.theme.ZoyaCrimson
import com.example.ui.theme.ZoyaCyanSecondary
import com.example.ui.theme.ZoyaElectricBlue
import com.example.ui.theme.ZoyaPinkTertiary
import com.example.ui.theme.ZoyaVioletPrimary
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ZoyaOrb(
    state: ZoyaState,
    modifier: Modifier = Modifier,
    size: Dp = 220.dp,
    isMuted: Boolean = false,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ZoyaOrbAnimation")

    // Slow breathing scale for IDLE & base states
    val breatheScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "OrbBreathe"
    )

    // Continuous rotation angle for THINKING & WORKING
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "OrbRotation"
    )

    // Reverse rotation angle
    val reverseRotationAngle by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "OrbReverseRotation"
    )

    // Expansion ripple for LISTENING
    val rippleProgress by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "OrbRipple"
    )

    // Dynamic wave oscillation for SPEAKING
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "OrbWavePhase"
    )

    val currentScale = if (isMuted) 0.95f else when (state) {
        ZoyaState.IDLE -> breatheScale
        ZoyaState.LISTENING -> 1.0f
        ZoyaState.THINKING -> breatheScale * 0.98f
        ZoyaState.WORKING -> breatheScale * 1.02f
        ZoyaState.SPEAKING -> breatheScale * 1.05f
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .scale(currentScale)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() }
            .testTag("zoya_animated_orb")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val radius = this.size.width / 2.8f

            if (isMuted) {
                // Muted aesthetic: Subtle crimson/gray glow & stroke
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            ZoyaCrimson.copy(alpha = 0.2f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = radius * 1.3f
                    ),
                    center = center,
                    radius = radius * 1.3f
                )

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF2D1525),
                            Color(0xFF151022),
                            Color(0xFF0B0914)
                        ),
                        center = center,
                        radius = radius
                    ),
                    center = center,
                    radius = radius
                )

                drawCircle(
                    color = ZoyaCrimson.copy(alpha = 0.5f),
                    center = center,
                    radius = radius,
                    style = Stroke(width = 2.dp.toPx())
                )
            } else {
                when (state) {
                    ZoyaState.IDLE -> {
                        // Outer ambient glow
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    ZoyaVioletPrimary.copy(alpha = 0.35f),
                                    ZoyaCyanSecondary.copy(alpha = 0.15f),
                                    Color.Transparent
                                ),
                                center = center,
                                radius = radius * 1.5f
                            ),
                            center = center,
                            radius = radius * 1.5f
                        )

                        // Core Gradient Orb
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    ZoyaCyanSecondary,
                                    ZoyaVioletPrimary,
                                    Color(0xFF0F0B26)
                                ),
                                center = center,
                                radius = radius
                            ),
                            center = center,
                            radius = radius
                        )

                        // Subtle outer border ring
                        drawCircle(
                            color = ZoyaCyanSecondary.copy(alpha = 0.6f),
                            center = center,
                            radius = radius,
                            style = Stroke(width = 3.dp.toPx())
                        )
                    }

                    ZoyaState.LISTENING -> {
                        // Expanding ripple rings
                        for (i in 0..2) {
                            val animatedRadius = radius * (1.0f + ((rippleProgress + i * 0.3f) % 1.0f) * 0.8f)
                            val alpha = (1.0f - (((rippleProgress + i * 0.3f) % 1.0f))).coerceIn(0f, 0.8f)
                            drawCircle(
                                color = ZoyaPinkTertiary.copy(alpha = alpha),
                                center = center,
                                radius = animatedRadius,
                                style = Stroke(width = 2.dp.toPx())
                            )
                        }

                        // Core Orb
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    ZoyaPinkTertiary,
                                    ZoyaVioletPrimary,
                                    ZoyaCrimson
                                ),
                                center = center,
                                radius = radius
                            ),
                            center = center,
                            radius = radius
                        )

                        // Audio visualizer dots around perimeter
                        val dotCount = 12
                        for (i in 0 until dotCount) {
                            val angle = (i * (360f / dotCount)) * (Math.PI / 180.0)
                            val dotDist = radius * 1.15f + sin(wavePhase + i).toFloat() * 10.dp.toPx()
                            val dotX = center.x + cos(angle).toFloat() * dotDist
                            val dotY = center.y + sin(angle).toFloat() * dotDist

                            drawCircle(
                                color = ZoyaCyanSecondary,
                                center = Offset(x = dotX, y = dotY),
                                radius = 4.dp.toPx()
                            )
                        }
                    }

                    ZoyaState.THINKING -> {
                        // Dual Rotating Segmented Rings
                        rotate(rotationAngle, center) {
                            drawCircle(
                                brush = Brush.sweepGradient(
                                    colors = listOf(
                                        ZoyaCyanSecondary,
                                        ZoyaElectricBlue,
                                        Color.Transparent,
                                        ZoyaVioletPrimary
                                    )
                                ),
                                center = center,
                                radius = radius * 1.25f,
                                style = Stroke(width = 4.dp.toPx())
                            )
                        }

                        rotate(reverseRotationAngle, center) {
                            drawCircle(
                                brush = Brush.sweepGradient(
                                    colors = listOf(
                                        ZoyaPinkTertiary,
                                        Color.Transparent,
                                        ZoyaCyanSecondary
                                    )
                                ),
                                center = center,
                                radius = radius * 1.4f,
                                style = Stroke(width = 2.dp.toPx())
                            )
                        }

                        // Core Pulsing Orb
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    ZoyaElectricBlue,
                                    ZoyaVioletPrimary,
                                    Color(0xFF0F172A)
                                ),
                                center = center,
                                radius = radius
                            ),
                            center = center,
                            radius = radius
                        )
                    }

                    ZoyaState.WORKING -> {
                        // Fast Energy Arcs
                        rotate(rotationAngle * 1.5f, center) {
                            drawArc(
                                color = ZoyaCrimson,
                                startAngle = 0f,
                                sweepAngle = 120f,
                                useCenter = false,
                                topLeft = Offset(center.x - radius * 1.3f, center.y - radius * 1.3f),
                                size = androidx.compose.ui.geometry.Size(radius * 2.6f, radius * 2.6f),
                                style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round)
                            )

                            drawArc(
                                color = ZoyaElectricBlue,
                                startAngle = 180f,
                                sweepAngle = 100f,
                                useCenter = false,
                                topLeft = Offset(center.x - radius * 1.3f, center.y - radius * 1.3f),
                                size = androidx.compose.ui.geometry.Size(radius * 2.6f, radius * 2.6f),
                                style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }

                        // Core Energy
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    ZoyaCyanSecondary,
                                    ZoyaVioletPrimary,
                                    Color.Black
                                ),
                                center = center,
                                radius = radius
                            ),
                            center = center,
                            radius = radius
                        )
                    }

                    ZoyaState.SPEAKING -> {
                        // Dynamic Voice Waveform Bars radiating around the orb
                        val barCount = 20
                        for (i in 0 until barCount) {
                            val angleDeg = i * (360f / barCount)
                            val angleRad = angleDeg * (Math.PI / 180.0)
                            val barHeight = (sin((wavePhase + i * 0.8f).toDouble()) * 20.dp.toPx() + 25.dp.toPx()).toFloat().coerceAtLeast(8.dp.toPx())

                            val startPoint = Offset(
                                x = center.x + cos(angleRad).toFloat() * radius,
                                y = center.y + sin(angleRad).toFloat() * radius
                            )
                            val endPoint = Offset(
                                x = center.x + cos(angleRad).toFloat() * (radius + barHeight),
                                y = center.y + sin(angleRad).toFloat() * (radius + barHeight)
                            )

                            drawLine(
                                brush = Brush.linearGradient(
                                    colors = listOf(ZoyaCyanSecondary, ZoyaPinkTertiary)
                                ),
                                start = startPoint,
                                end = endPoint,
                                strokeWidth = 3.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }

                        // Oscillating Core
                        val path = Path()
                        val waveAmplitude = 12.dp.toPx()
                        path.moveTo(center.x - radius, center.y)
                        for (x in -radius.toInt()..radius.toInt() step 5) {
                            val normalizedX = x.toFloat() / radius
                            val y = sin((normalizedX * Math.PI * 3 + wavePhase).toDouble()) * waveAmplitude * (1 - normalizedX * normalizedX)
                            path.lineTo(center.x + x, center.y + y.toFloat())
                        }

                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    ZoyaVioletPrimary,
                                    ZoyaPinkTertiary,
                                    Color(0xFF0F0B26)
                                ),
                                center = center,
                                radius = radius
                            ),
                            center = center,
                            radius = radius
                        )

                        drawPath(
                            path = path,
                            color = ZoyaCyanSecondary,
                            style = Stroke(width = 3.dp.toPx())
                        )
                    }
                }
            }
        }

        // Central Icon indicator reflecting the current ZoyaState or Muted state
        val icon = if (isMuted) {
            Icons.Default.VolumeOff
        } else {
            when (state) {
                ZoyaState.IDLE -> Icons.Default.SmartToy
                ZoyaState.LISTENING -> Icons.Default.Mic
                ZoyaState.THINKING -> Icons.Default.Psychology
                ZoyaState.WORKING -> Icons.Default.Sync
                ZoyaState.SPEAKING -> Icons.Default.RecordVoiceOver
            }
        }

        val iconTint = if (isMuted) {
            ZoyaCrimson
        } else {
            when (state) {
                ZoyaState.IDLE -> ZoyaCyanSecondary
                ZoyaState.LISTENING -> ZoyaPinkTertiary
                ZoyaState.THINKING -> ZoyaElectricBlue
                ZoyaState.WORKING -> ZoyaCyanSecondary
                ZoyaState.SPEAKING -> Color.White
            }
        }

        Icon(
            imageVector = icon,
            contentDescription = if (isMuted) "Muted" else state.statusMessage,
            tint = iconTint,
            modifier = Modifier.size(54.dp)
        )
    }
}
