package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ZoyaCrimson
import com.example.ui.theme.ZoyaCyanSecondary
import com.example.ui.theme.ZoyaDarkBackground
import com.example.ui.theme.ZoyaDarkCard
import com.example.ui.theme.ZoyaDarkSurface
import com.example.ui.theme.ZoyaVioletPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: ZoyaViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToPeople: (() -> Unit)? = null,
    onNavigateToMemory: (() -> Unit)? = null,
    onNavigateToPrivacy: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val prefs by viewModel.userPreferences.collectAsState()
    val coreMemory by viewModel.coreMemory.collectAsState()

    var userNameInput by remember(prefs.userName) { mutableStateOf(prefs.userName) }
    var userTitleInput by remember(prefs.preferredTitle) { mutableStateOf(prefs.preferredTitle) }

    var showEditCoreMemoryDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "ZOYA Settings",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("settings_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ZoyaDarkSurface
                )
            )
        },
        containerColor = ZoyaDarkBackground,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Identity Section
            Card(
                colors = CardDefaults.cardColors(containerColor = ZoyaDarkCard),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = ZoyaCyanSecondary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "User Identity & Title",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }

                    OutlinedTextField(
                        value = userNameInput,
                        onValueChange = {
                            userNameInput = it
                            viewModel.updateUserName(it.ifBlank { "Sonu" })
                        },
                        label = { Text("Your Name", color = Color.Gray) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_name_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = ZoyaCyanSecondary,
                            unfocusedBorderColor = Color.Gray
                        )
                    )

                    OutlinedTextField(
                        value = userTitleInput,
                        onValueChange = {
                            userTitleInput = it
                            viewModel.updatePreferredTitle(it.ifBlank { "Boss" })
                        },
                        label = { Text("Preferred Salutation (e.g. Boss, Sir)", color = Color.Gray) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_title_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = ZoyaCyanSecondary,
                            unfocusedBorderColor = Color.Gray
                        )
                    )
                }
            }

            // Saved Long-Term Permanent Memory Section
            Card(
                colors = CardDefaults.cardColors(containerColor = ZoyaDarkCard),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Memory,
                                contentDescription = null,
                                tint = ZoyaVioletPrimary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Saved Long-Term Memory",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                        }

                        IconButton(
                            onClick = { showEditCoreMemoryDialog = true },
                            modifier = Modifier.testTag("edit_core_memory_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Core Memory",
                                tint = ZoyaCyanSecondary
                            )
                        }
                    }

                    Text("Stored Permanent Core Facts Across Sessions:", color = Color.Gray, fontSize = 12.sp)

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(ZoyaDarkSurface, RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("• Primary Master: ${coreMemory.userName} (${coreMemory.preferredTitle})", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("• App Creator: ${coreMemory.appCreator}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("• Context: ${coreMemory.personalityContext}", color = Color.LightGray, fontSize = 11.sp)

                        if (coreMemory.customMemories.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Explicit Learned Facts (${coreMemory.customMemories.size}):", color = ZoyaCyanSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            coreMemory.customMemories.take(3).forEach { fact ->
                                Text("• ${fact.fact}", color = Color.White, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            if (showEditCoreMemoryDialog) {
                var editName by remember { mutableStateOf(coreMemory.userName) }
                var editTitle by remember { mutableStateOf(coreMemory.preferredTitle) }
                var editCreator by remember { mutableStateOf(coreMemory.appCreator) }
                var editContext by remember { mutableStateOf(coreMemory.personalityContext) }

                AlertDialog(
                    onDismissRequest = { showEditCoreMemoryDialog = false },
                    title = { Text("Edit Saved Core Memory", color = Color.White) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = editName,
                                onValueChange = { editName = it },
                                label = { Text("User Name") },
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                            )
                            OutlinedTextField(
                                value = editTitle,
                                onValueChange = { editTitle = it },
                                label = { Text("Preferred Title") },
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                            )
                            OutlinedTextField(
                                value = editCreator,
                                onValueChange = { editCreator = it },
                                label = { Text("App Creator") },
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                            )
                            OutlinedTextField(
                                value = editContext,
                                onValueChange = { editContext = it },
                                label = { Text("Personality Context") },
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.updateCoreLongTermMemory(
                                    userName = editName.ifBlank { "Sonu" },
                                    preferredTitle = editTitle.ifBlank { "Boss" },
                                    appCreator = editCreator.ifBlank { "Sonu Boss" },
                                    personalityContext = editContext.ifBlank { "Sonu Boss is my creator who built me with hard work. I am Zoya, his personal AI companion." }
                                )
                                showEditCoreMemoryDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ZoyaVioletPrimary)
                        ) {
                            Text("Save Memory")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showEditCoreMemoryDialog = false }) {
                            Text("Cancel", color = Color.Gray)
                        }
                    },
                    containerColor = ZoyaDarkCard
                )
            }

            // Voice Settings Section
            Card(
                colors = CardDefaults.cardColors(containerColor = ZoyaDarkCard),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = null,
                            tint = ZoyaCyanSecondary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ZOYA Voice Personality & Settings",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }

                    // Voice Selection
                    Column {
                        Text("Supported Voice Model", color = Color.Gray, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        val voiceOptions = listOf("Default Synthetic Female", "Cute Companion Voice", "Expressive Companion")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            voiceOptions.forEach { vName ->
                                val selected = prefs.selectedVoiceName == vName
                                Button(
                                    onClick = { viewModel.updateSelectedVoiceName(vName) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selected) ZoyaCyanSecondary else ZoyaDarkSurface,
                                        contentColor = if (selected) Color.Black else Color.White
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(vName.split(" ")[0], fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }

                    // Voice Speed
                    Column {
                        Text("Voice Speed", color = Color.Gray, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        val speeds = listOf("Slow", "Normal", "Fast")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            speeds.forEach { spd ->
                                val selected = prefs.voiceSpeed == spd
                                Button(
                                    onClick = { viewModel.updateVoiceSpeed(spd) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selected) ZoyaVioletPrimary else ZoyaDarkSurface,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(spd, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Voice Style
                    Column {
                        Text("Voice Style / Emotion", color = Color.Gray, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        val styles = listOf("Cute", "Friendly", "Funny", "Calm", "Expressive")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            styles.forEach { stl ->
                                val selected = prefs.voiceStyle == stl
                                Button(
                                    onClick = { viewModel.updateVoiceStyle(stl) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selected) ZoyaCyanSecondary else ZoyaDarkSurface,
                                        contentColor = if (selected) Color.Black else Color.White
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(stl, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Humor Level Control
                    Column {
                        Text("Humor Level", color = Color.Gray, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        val humorLevels = listOf("Low", "Normal", "Funny", "Extra Funny")
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            humorLevels.forEach { hLevel ->
                                val selected = prefs.humorLevel == hLevel
                                Button(
                                    onClick = { viewModel.updateHumorLevel(hLevel) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selected) ZoyaVioletPrimary else ZoyaDarkSurface,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(hLevel, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Emotion Level Control
                    Column {
                        Text("Emotion Level", color = Color.Gray, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        val emotionLevels = listOf("Calm", "Friendly", "Expressive")
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            emotionLevels.forEach { eLevel ->
                                val selected = prefs.emotionLevel == eLevel
                                Button(
                                    onClick = { viewModel.updateEmotionLevel(eLevel) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selected) ZoyaCyanSecondary else ZoyaDarkSurface,
                                        contentColor = if (selected) Color.Black else Color.White
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(eLevel, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Speaking Style Mode
                    Column {
                        Text("Speaking Style Mode", color = Color.Gray, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        val speakingStyles = listOf("Hindi", "Hinglish", "English", "Auto")
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            speakingStyles.forEach { sStyle ->
                                val selected = prefs.speakingStyle == sStyle
                                Button(
                                    onClick = { viewModel.updateSpeakingStyle(sStyle) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selected) ZoyaVioletPrimary else ZoyaDarkSurface,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(sStyle, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Language Selection
                    Column {
                        Text("Target Voice Language", color = Color.Gray, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        val languages = listOf("Hinglish", "Hindi", "English", "Auto")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            languages.forEach { lang ->
                                val selected = prefs.voiceLanguage == lang
                                Button(
                                    onClick = { viewModel.updateVoiceLanguage(lang) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selected) ZoyaVioletPrimary else ZoyaDarkSurface,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(lang, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Preview Voice Button
                    Button(
                        onClick = { viewModel.previewVoice() },
                        colors = ButtonDefaults.buttonColors(containerColor = ZoyaCyanSecondary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("settings_preview_voice_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = "Preview",
                                tint = Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("🔊 Preview Selected ZOYA Voice", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }

            // Voice & Wake Word Control Section
            Card(
                colors = CardDefaults.cardColors(containerColor = ZoyaDarkCard),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = ZoyaVioletPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Voice Commands & Audio Controls",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }

                    // Voice Commands ON/OFF Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Voice Commands (Aawaz se Baat)", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text(if (prefs.voiceCommandsEnabled) "Voice recognition enabled (Active)" else "Voice commands band (Disabled)", color = Color.Gray, fontSize = 12.sp)
                        }
                        Switch(
                            checked = prefs.voiceCommandsEnabled,
                            onCheckedChange = { viewModel.setVoiceCommandsEnabled(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = ZoyaCyanSecondary),
                            modifier = Modifier.testTag("settings_voice_commands_switch")
                        )
                    }

                    // Audio Mute Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Mute ZOYA Audio (Aawaz Band/Chalu)", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text(if (prefs.isMuted) "Audio Muted (Silent Mode)" else "Audio Output ON (Zoya bole gi)", color = if (prefs.isMuted) ZoyaCrimson else Color.Gray, fontSize = 12.sp)
                        }
                        Switch(
                            checked = prefs.isMuted,
                            onCheckedChange = { viewModel.setMuted(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = ZoyaCrimson, checkedTrackColor = ZoyaCrimson.copy(alpha = 0.5f)),
                            modifier = Modifier.testTag("settings_mute_switch")
                        )
                    }

                    // Wake Word Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Wake Word Detection (\"Hey Zoya\")", color = Color.White, fontSize = 14.sp)
                            Text("Always listen for 'Hey Zoya' trigger", color = Color.Gray, fontSize = 12.sp)
                        }
                        Switch(
                            checked = prefs.wakeWordEnabled,
                            onCheckedChange = { viewModel.toggleWakeWord(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = ZoyaCyanSecondary),
                            modifier = Modifier.testTag("settings_wake_word_switch")
                        )
                    }
                }
            }

            // People, Memory & Privacy Center Hub
            Card(
                colors = CardDefaults.cardColors(containerColor = ZoyaDarkCard),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "ZOYA Intelligence & Security Modules",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )

                    // People & Family System
                    Button(
                        onClick = { onNavigateToPeople?.invoke() },
                        colors = ButtonDefaults.buttonColors(containerColor = ZoyaDarkSurface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("nav_people_button")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = ZoyaCyanSecondary)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("People & Family System", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Manage contacts & natural family relations", color = Color.Gray, fontSize = 10.sp)
                            }
                        }
                    }

                    // Explicit Memory Bank
                    Button(
                        onClick = { onNavigateToMemory?.invoke() },
                        colors = ButtonDefaults.buttonColors(containerColor = ZoyaDarkSurface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("nav_memory_button")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = ZoyaVioletPrimary)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Explicit Memory Bank", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("View, edit, and delete saved facts", color = Color.Gray, fontSize = 10.sp)
                            }
                        }
                    }

                    // Privacy & Protected Apps Center
                    Button(
                        onClick = { onNavigateToPrivacy?.invoke() },
                        colors = ButtonDefaults.buttonColors(containerColor = ZoyaDarkSurface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("nav_privacy_button")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = ZoyaCrimson)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Privacy & Protected Apps Center", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("App lock protection & active security shield", color = Color.Gray, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }

            // Routine & Greetings Section
            Card(
                colors = CardDefaults.cardColors(containerColor = ZoyaDarkCard),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = null,
                            tint = ZoyaCyanSecondary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Daily Routine Greetings",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Morning Briefing Greeting", color = Color.White, fontSize = 14.sp)
                        Switch(
                            checked = prefs.morningGreetingEnabled,
                            onCheckedChange = { viewModel.toggleMorningGreeting(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = ZoyaCyanSecondary)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Night Shutdown Greeting", color = Color.White, fontSize = 14.sp)
                        Switch(
                            checked = prefs.nightGreetingEnabled,
                            onCheckedChange = { viewModel.toggleNightGreeting(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = ZoyaCyanSecondary)
                        )
                    }
                }
            }

            // Background Assistant Service Section
            Card(
                colors = CardDefaults.cardColors(containerColor = ZoyaDarkCard),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = ZoyaCyanSecondary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Foreground Service Shield",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Background Audio Assistant Service", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text("Keep ZOYA active in notification drawer with voice shield", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = prefs.isBackgroundServiceEnabled,
                            onCheckedChange = { viewModel.toggleBackgroundService(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = ZoyaCyanSecondary),
                            modifier = Modifier.testTag("settings_bg_service_switch")
                        )
                    }
                }
            }

            // Privacy Guarantee
            Card(
                colors = CardDefaults.cardColors(containerColor = ZoyaDarkCard),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = ZoyaVioletPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Privacy Shield Status",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }

                    Text(
                        text = "• On-device DataStore Encrypted\n• Microphones active only during voice sessions\n• Zero data sell policy for Sonu Boss",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }

            // Danger Zone / Reset
            Button(
                onClick = { viewModel.clearChat() },
                colors = ButtonDefaults.buttonColors(containerColor = ZoyaCrimson),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("settings_clear_history_button")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CleaningServices,
                        contentDescription = "Clear History",
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Clear Chat & Session History", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
