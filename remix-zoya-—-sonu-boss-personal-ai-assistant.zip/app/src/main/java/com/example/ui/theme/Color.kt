package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ZoyaVioletPrimary = Color(0xFF8B5CF6)
val ZoyaCyanSecondary = Color(0xFF06B6D4)
val ZoyaPinkTertiary = Color(0xFFEC4899)
val ZoyaElectricBlue = Color(0xFF3B82F6)
val ZoyaCrimson = Color(0xFFE11D48)

val ZoyaDarkBackground = Color(0xFF0A0E1A)
val ZoyaDarkSurface = Color(0xFF131B2E)
val ZoyaDarkCard = Color(0xFF1E293B)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

