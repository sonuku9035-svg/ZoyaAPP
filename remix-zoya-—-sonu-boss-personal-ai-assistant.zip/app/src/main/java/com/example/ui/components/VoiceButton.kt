package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.ZoyaState
import com.example.ui.theme.ZoyaCrimson
import com.example.ui.theme.ZoyaCyanSecondary
import com.example.ui.theme.ZoyaElectricBlue
import com.example.ui.theme.ZoyaPinkTertiary
import com.example.ui.theme.ZoyaVioletPrimary

/**
 * Large glowing VoiceButton for One-Tap speech activation & interruption.
 */
@Composable
fun VoiceButton(
    state: ZoyaState,
    isMuted: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 80.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "VoiceButtonPulse")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (state == ZoyaState.LISTENING) 1.12f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "VoiceButtonScale"
    )

    val backgroundBrush = when {
        isMuted -> Brush.linearGradient(
            listOf(Color(0xFF334155), Color(0xFF1E293B))
        )
        state == ZoyaState.LISTENING -> Brush.linearGradient(
            listOf(ZoyaPinkTertiary, ZoyaCrimson)
        )
        state == ZoyaState.SPEAKING -> Brush.linearGradient(
            listOf(ZoyaCrimson, ZoyaVioletPrimary)
        )
        state == ZoyaState.THINKING -> Brush.linearGradient(
            listOf(ZoyaElectricBlue, ZoyaVioletPrimary)
        )
        else -> Brush.linearGradient(
            listOf(ZoyaVioletPrimary, ZoyaCyanSecondary)
        )
    }

    val icon = when {
        isMuted -> Icons.Default.MicOff
        state == ZoyaState.LISTENING -> Icons.Default.Stop
        state == ZoyaState.SPEAKING -> Icons.Default.Stop
        else -> Icons.Default.Mic
    }

    val contentDesc = when {
        isMuted -> "Unmute and Speak"
        state == ZoyaState.LISTENING -> "Stop Listening"
        state == ZoyaState.SPEAKING -> "Interrupt Zoya"
        else -> "Start Speaking to Zoya"
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .scale(if (state == ZoyaState.LISTENING) pulseScale else 1.0f)
            .clip(CircleShape)
            .background(backgroundBrush)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = true, color = Color.White),
                onClick = onClick
            )
            .testTag("voice_microphone_button")
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDesc,
            tint = Color.White,
            modifier = Modifier.size(size * 0.5f)
        )
    }
}
