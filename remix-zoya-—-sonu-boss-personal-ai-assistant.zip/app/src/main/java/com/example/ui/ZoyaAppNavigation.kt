package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

object ZoyaRoutes {
    const val ONBOARDING = "onboarding"
    const val MAIN = "main"
    const val SETTINGS = "settings"
    const val PEOPLE = "people"
    const val MEMORY = "memory"
    const val PRIVACY = "privacy"
}

@Composable
fun ZoyaAppNavigation(
    viewModel: ZoyaViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val preferences by viewModel.userPreferences.collectAsState()

    // Permission Request Handler
    var hasRecordAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasRecordAudioPermission = isGranted
    }

    LaunchedEffect(Unit) {
        if (!hasRecordAudioPermission) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val startDestination = ZoyaRoutes.MAIN

    NavHost(
        navController = navController,
        startDestination = startDestination,
        modifier = modifier.fillMaxSize()
    ) {
        composable(ZoyaRoutes.ONBOARDING) {
            FirstTimeSetupScreen(
                onSetupComplete = { name, title ->
                    viewModel.updateUserName(name)
                    viewModel.updatePreferredTitle(title)
                    navController.navigate(ZoyaRoutes.MAIN) {
                        popUpTo(ZoyaRoutes.ONBOARDING) { inclusive = true }
                    }
                }
            )
        }

        composable(ZoyaRoutes.MAIN) {
            MainAssistantScreen(
                viewModel = viewModel,
                onNavigateToSettings = {
                    navController.navigate(ZoyaRoutes.SETTINGS)
                }
            )
        }

        composable(ZoyaRoutes.SETTINGS) {
            SettingsScreen(
                viewModel = viewModel,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateToPeople = {
                    navController.navigate(ZoyaRoutes.PEOPLE)
                },
                onNavigateToMemory = {
                    navController.navigate(ZoyaRoutes.MEMORY)
                },
                onNavigateToPrivacy = {
                    navController.navigate(ZoyaRoutes.PRIVACY)
                }
            )
        }

        composable(ZoyaRoutes.PEOPLE) {
            PeopleScreen(
                peopleManager = viewModel.peopleManager,
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(ZoyaRoutes.MEMORY) {
            MemoryScreen(
                memoryManager = viewModel.memoryManager,
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(ZoyaRoutes.PRIVACY) {
            PrivacyCenterScreen(
                protectedAppsManager = viewModel.protectedAppsManager,
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}
