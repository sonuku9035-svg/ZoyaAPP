package com.example.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.db.ProtectedAppEntity
import com.example.privacy.ProtectedAppsManager
import com.example.ui.theme.ZoyaCrimson
import com.example.ui.theme.ZoyaCyanSecondary
import com.example.ui.theme.ZoyaDarkBackground
import com.example.ui.theme.ZoyaDarkCard
import com.example.ui.theme.ZoyaDarkSurface
import com.example.ui.theme.ZoyaVioletPrimary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyCenterScreen(
    protectedAppsManager: ProtectedAppsManager,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val protectedAppsList by protectedAppsManager.protectedAppsFlow.collectAsState(initial = emptyList())

    var showAddAppDialog by remember { mutableStateOf(false) }

    // Pre-populate sample lock list if empty
    val sampleApps = listOf(
        Pair("com.google.android.apps.photos", "Private Gallery & Photos"),
        Pair("com.whatsapp", "WhatsApp Private Chats"),
        Pair("com.hidden.vault", "Hidden Vault & Files"),
        Pair("android.settings.SETTINGS", "System Settings Shield")
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Privacy & Protected Apps Center",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("privacy_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = ZoyaDarkSurface)
            )
        },
        containerColor = ZoyaDarkBackground,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Active Security Shield Banner
            Card(
                colors = CardDefaults.cardColors(containerColor = ZoyaDarkCard),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = ZoyaCyanSecondary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ZOYA Privacy Guard Active",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 16.sp
                        )
                    }
                    Text(
                        text = "Protected apps request severe blocking: 'Boss, ye app aapne protected rakha hai. Main ise open nahi karungi.'",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            // Quick Add Custom App Lock Button
            Button(
                onClick = { showAddAppDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = ZoyaVioletPrimary),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Add App to Lock List", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }

            Text(
                text = "App Lock Protection List:",
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontSize = 15.sp
            )

            // Combine actual list with predefined samples
            val displayList = sampleApps.map { sample ->
                val match = protectedAppsList.find { it.packageName == sample.first }
                match ?: ProtectedAppEntity(packageName = sample.first, appName = sample.second, isLocked = false)
            } + protectedAppsList.filter { dbItem -> sampleApps.none { it.first == dbItem.packageName } }

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(displayList, key = { it.packageName }) { appEntity ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ZoyaDarkCard),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = if (appEntity.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                    contentDescription = null,
                                    tint = if (appEntity.isLocked) ZoyaCrimson else Color.Gray,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = appEntity.appName,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = appEntity.packageName,
                                        color = Color.Gray,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Switch(
                                checked = appEntity.isLocked,
                                onCheckedChange = { isChecked ->
                                    coroutineScope.launch {
                                        protectedAppsManager.toggleAppLock(
                                            packageName = appEntity.packageName,
                                            appName = appEntity.appName,
                                            shouldLock = isChecked
                                        )
                                    }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = ZoyaCrimson,
                                    checkedTrackColor = ZoyaDarkSurface
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddAppDialog) {
        var appNameInput by remember { mutableStateOf("") }
        var packageInput by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddAppDialog = false },
            title = { Text("Lock Custom Application", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = appNameInput,
                        onValueChange = { appNameInput = it },
                        label = { Text("App Name (e.g. Banking App)", color = Color.Gray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = ZoyaCyanSecondary,
                            unfocusedBorderColor = Color.Gray
                        )
                    )
                    OutlinedTextField(
                        value = packageInput,
                        onValueChange = { packageInput = it },
                        label = { Text("Package Name (e.g. com.bank.app)", color = Color.Gray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = ZoyaCyanSecondary,
                            unfocusedBorderColor = Color.Gray
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (appNameInput.isNotBlank() && packageInput.isNotBlank()) {
                            coroutineScope.launch {
                                protectedAppsManager.addProtectedApp(packageInput.trim(), appNameInput.trim())
                                showAddAppDialog = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ZoyaVioletPrimary)
                ) {
                    Text("Add Lock Protection", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddAppDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = ZoyaDarkCard
        )
    }
}
