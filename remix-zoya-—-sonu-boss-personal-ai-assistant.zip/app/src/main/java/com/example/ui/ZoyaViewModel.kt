package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiLiveSessionManager
import com.example.ai.GeminiLiveState
import com.example.ai.GeminiLiveWebSocketClient
import com.example.data.PreferencesManager
import com.example.data.UserPreferences
import com.example.model.ChatMessage
import com.example.model.MessageSender
import com.example.model.ZoyaPersonality
import com.example.model.ZoyaState
import com.example.voice.SpeechManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

class ZoyaViewModel(application: Application) : AndroidViewModel(application) {

    val peopleManager by lazy { com.example.people.PeopleManager.create(getApplication()) }
    val memoryManager by lazy { com.example.memory.MemoryManager.create(getApplication()) }
    val memoryRepository by lazy { com.example.memory.MemoryRepository.create(getApplication()) }
    val protectedAppsManager by lazy { com.example.privacy.ProtectedAppsManager.create(getApplication()) }
    val toolExecutionEngine by lazy { com.example.tools.ToolExecutionEngine(getApplication()) }

    private val preferencesManager = PreferencesManager(application)
    private val geminiSessionManager = GeminiLiveSessionManager()

    private var speechManager: SpeechManager? = null
    private var liveWebSocketClient: GeminiLiveWebSocketClient? = null
    private val _isLiveWebSocketActive = MutableStateFlow(false)
    val isLiveWebSocketActive: StateFlow<Boolean> = _isLiveWebSocketActive.asStateFlow()

    private val _coreMemory = MutableStateFlow(com.example.memory.CoreLongTermMemory())
    val coreMemory: StateFlow<com.example.memory.CoreLongTermMemory> = _coreMemory.asStateFlow()

    val userPreferences: StateFlow<UserPreferences> = preferencesManager.userPreferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = UserPreferences()
        )

    private val _currentState = MutableStateFlow(ZoyaState.IDLE)
    val currentState: StateFlow<ZoyaState> = _currentState.asStateFlow()

    private val _liveSpeechTranscript = MutableStateFlow("")
    val liveSpeechTranscript: StateFlow<String> = _liveSpeechTranscript.asStateFlow()

    private val _rmsAudioLevel = MutableStateFlow(0f)
    val rmsAudioLevel: StateFlow<Float> = _rmsAudioLevel.asStateFlow()

    private val _voiceErrorMessage = MutableStateFlow<String?>(null)
    val voiceErrorMessage: StateFlow<String?> = _voiceErrorMessage.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _memoryItems = MutableStateFlow<List<String>>(
        listOf(
            "Primary User: Sonu Boss",
            "Personality Mode: Witty, playful, ultra-caring",
            "Preferred Salutation: Boss / Sonu Boss",
            "Default Language: Hinglish / English Mix",
            "System Status: All local engines nominal"
        )
    )
    val memoryItems: StateFlow<List<String>> = _memoryItems.asStateFlow()

    private val _privacyStatus = MutableStateFlow(
        mapOf(
            "Local Voice Processing" to "Enabled",
            "Encrypted DataStore" to "Active",
            "Data Sharing" to "Disabled (Strict Privacy)",
            "Cloud Sync" to "Disabled (Local First)"
        )
    )
    val privacyStatus: StateFlow<Map<String, String>> = _privacyStatus.asStateFlow()

    init {
        addZoyaGreeting()
        initVoiceEngine(application)
        loadCoreMemories()
    }

    fun loadCoreMemories() {
        viewModelScope.launch {
            memoryRepository.initCorePermanentMemories()
            _coreMemory.value = memoryRepository.getCoreLongTermMemory()
        }
    }

    private fun initVoiceEngine(app: Application) {
        try {
            liveWebSocketClient = GeminiLiveWebSocketClient(
                context = app,
                onStateChanged = { liveState ->
                    when (liveState) {
                        is GeminiLiveState.Connecting -> {
                            _currentState.value = ZoyaState.THINKING
                            _isLiveWebSocketActive.value = true
                        }
                        is GeminiLiveState.Connected -> {
                            _currentState.value = ZoyaState.LISTENING
                            _isLiveWebSocketActive.value = true
                        }
                        is GeminiLiveState.Listening -> {
                            _currentState.value = ZoyaState.LISTENING
                            _isLiveWebSocketActive.value = true
                        }
                        is GeminiLiveState.Thinking -> {
                            _currentState.value = ZoyaState.THINKING
                        }
                        is GeminiLiveState.Speaking -> {
                            _currentState.value = ZoyaState.SPEAKING
                        }
                        is GeminiLiveState.Disconnected -> {
                            _isLiveWebSocketActive.value = false
                        }
                        is GeminiLiveState.Error -> {
                            _isLiveWebSocketActive.value = false
                        }
                    }
                },
                onRmsChanged = { level ->
                    _rmsAudioLevel.value = level
                },
                onTranscriptReceived = { text, _ ->
                    _liveSpeechTranscript.value = text
                    val zoyaMsg = ChatMessage(sender = MessageSender.ZOYA, text = text)
                    _messages.value = _messages.value + zoyaMsg
                }
            )

            speechManager = SpeechManager(
                context = app,
                onSpeechResult = { recognizedText ->
                    _liveSpeechTranscript.value = recognizedText
                    _voiceErrorMessage.value = null
                    processVoiceInput(recognizedText)
                },
                onSpeechPartialResult = { partial ->
                    _liveSpeechTranscript.value = partial
                },
                onSpeechListeningStateChanged = { listening ->
                    if (listening) {
                        _currentState.value = ZoyaState.LISTENING
                    } else if (_currentState.value == ZoyaState.LISTENING) {
                        _currentState.value = ZoyaState.THINKING
                    }
                },
                onRmsChangedCallback = { level ->
                    _rmsAudioLevel.value = level
                },
                onError = { errorMsg ->
                    if (_currentState.value == ZoyaState.LISTENING) {
                        _currentState.value = ZoyaState.IDLE
                    }
                    _voiceErrorMessage.value = if (errorMsg.contains("permission", ignoreCase = true)) {
                        "Microphone permission chahiye Boss!"
                    } else {
                        "Sunne mein dikkat aayi, Boss! Quick voice command tap karein ya dobara bolein."
                    }
                }
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun addZoyaGreeting() {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greetingText = if (hour in 5..11) {
            ZoyaPersonality.GREETINGS_MORNING.random()
        } else if (hour in 21..23 || hour in 0..4) {
            ZoyaPersonality.GREETINGS_NIGHT.random()
        } else {
            "Ji Sonu Boss 😎 Main ZOYA hoon, aapki personal AI assistant. Kahiye aaj kya shuru karein?"
        }

        _messages.value = listOf(
            ChatMessage(
                sender = MessageSender.ZOYA,
                text = greetingText
            )
        )
    }

    fun setState(newState: ZoyaState) {
        _currentState.value = newState
    }

    fun sendMessage(userText: String) {
        if (userText.isBlank()) return

        speechManager?.stopSpeaking()

        val userMsg = ChatMessage(sender = MessageSender.USER, text = userText)
        _messages.value = _messages.value + userMsg

        processAiResponse(userText)
    }

    private fun processVoiceInput(recognizedText: String) {
        if (recognizedText.isBlank()) {
            _currentState.value = ZoyaState.IDLE
            return
        }

        val userMsg = ChatMessage(sender = MessageSender.USER, text = recognizedText)
        _messages.value = _messages.value + userMsg

        processAiResponse(recognizedText)
    }

    private fun processAiResponse(input: String) {
        viewModelScope.launch {
            _currentState.value = ZoyaState.THINKING

            val prefs = userPreferences.value

            // 1. Check Family & People Teaching Commands ("Zoya ye meri mummy hain", "ye mummy nahi bhabhi hain")
            val familyResult = peopleManager.processTeachingCommand(input, prefs.preferredTitle)
            val finalResponseText = if (familyResult.handled) {
                familyResult.feedbackMessage
            } else {
                // 2. Check Explicit Memory Commands ("Zoya ye yaad rakhna...")
                val memoryResult = memoryManager.processExplicitMemoryCommand(input, prefs.preferredTitle)
                if (memoryResult.handled) {
                    memoryResult.feedbackMessage
                } else {
                    // 3. Tool Execution Engine (System actions, apps, confirmation flow, context follow-ups)
                    val toolResult = toolExecutionEngine.executeTool(
                        input = input,
                        userName = prefs.userName,
                        title = prefs.preferredTitle,
                        protectedAppsManager = protectedAppsManager
                    )

                    if (toolResult.handled && !toolResult.feedbackMessage.isNullOrBlank()) {
                        toolResult.feedbackMessage
                    } else {
                        // 4. Command Router Fallback
                        val cmdResult = com.example.router.CommandRouter.executeCommand(
                            context = getApplication(),
                            input = input,
                            userName = prefs.userName,
                            title = prefs.preferredTitle,
                            protectedAppsManager = protectedAppsManager
                        )

                        if (cmdResult.handled && !cmdResult.feedbackMessage.isNullOrBlank()) {
                            cmdResult.feedbackMessage
                        } else {
                            // 5. Route to Gemini AI for natural language conversation
                            val coreMem = _coreMemory.value
                            geminiSessionManager.sendMessage(
                                userMessage = input,
                                userName = prefs.userName,
                                preferredTitle = prefs.preferredTitle,
                                voiceStyle = prefs.voiceStyle,
                                voiceLanguage = prefs.voiceLanguage,
                                appCreator = coreMem.appCreator,
                                personalityContext = coreMem.personalityContext,
                                customMemories = coreMem.customMemories.map { it.fact }
                            )
                        }
                    }
                }
            }

            val zoyaMsg = ChatMessage(sender = MessageSender.ZOYA, text = finalResponseText)
            _messages.value = _messages.value + zoyaMsg

            speakZoyaResponse(finalResponseText)
        }
    }

    fun speakText(text: String) {
        speakZoyaResponse(text)
    }

    fun stopSpeaking() {
        liveWebSocketClient?.interruptPlayback()
        speechManager?.stopSpeaking()
        if (_currentState.value == ZoyaState.SPEAKING) {
            _currentState.value = ZoyaState.IDLE
        }
    }

    fun startLiveVoiceSession() {
        val prefs = userPreferences.value
        if (!prefs.voiceCommandsEnabled) {
            _voiceErrorMessage.value = "Voice Commands band (OFF) hain Boss! Top bar se Voice ON karein."
            return
        }

        stopSpeaking()
        _liveSpeechTranscript.value = ""
        _voiceErrorMessage.value = null
        
        val coreMem = _coreMemory.value
        val systemPrompt = ZoyaPersonality.getDynamicSystemPrompt(
            userName = prefs.userName,
            preferredTitle = prefs.preferredTitle,
            voiceStyle = prefs.voiceStyle,
            voiceLanguage = prefs.voiceLanguage,
            appCreator = coreMem.appCreator,
            personalityContext = coreMem.personalityContext,
            customMemories = coreMem.customMemories.map { it.fact }
        )

        liveWebSocketClient?.startLiveSession(systemPrompt)
    }

    fun stopLiveVoiceSession() {
        liveWebSocketClient?.stopLiveSession()
        _isLiveWebSocketActive.value = false
    }

    private fun speakZoyaResponse(text: String) {
        val prefs = userPreferences.value
        if (prefs.isMuted) {
            _currentState.value = ZoyaState.IDLE
            return
        }

        _currentState.value = ZoyaState.SPEAKING
        speechManager?.speak(
            text = text,
            speed = prefs.voiceSpeed,
            style = prefs.voiceStyle,
            onStart = {
                _currentState.value = ZoyaState.SPEAKING
            },
            onDone = {
                _currentState.value = ZoyaState.IDLE
            }
        ) ?: run {
            _currentState.value = ZoyaState.IDLE
        }
    }

    fun previewVoice(
        speed: String = userPreferences.value.voiceSpeed,
        style: String = userPreferences.value.voiceStyle,
        language: String = userPreferences.value.voiceLanguage
    ) {
        val previewText = "Ji Sonu Boss 😎 Main ZOYA hoon, aapki personal AI assistant. Kahiye aaj kya mast plan hai?"

        _currentState.value = ZoyaState.SPEAKING
        speechManager?.speak(
            text = previewText,
            speed = speed,
            style = style,
            onStart = { _currentState.value = ZoyaState.SPEAKING },
            onDone = { _currentState.value = ZoyaState.IDLE }
        )
    }

    fun toggleMute() {
        viewModelScope.launch {
            val newMuted = !userPreferences.value.isMuted
            if (newMuted) {
                stopSpeaking()
                stopLiveVoiceSession()
            }
            preferencesManager.setMuted(newMuted)
        }
    }

    fun toggleVoiceCommands() {
        viewModelScope.launch {
            val newEnabled = !userPreferences.value.voiceCommandsEnabled
            if (!newEnabled) {
                stopLiveVoiceSession()
                speechManager?.stopListening()
                if (_currentState.value == ZoyaState.LISTENING) {
                    _currentState.value = ZoyaState.IDLE
                }
            }
            preferencesManager.setVoiceCommandsEnabled(newEnabled)
        }
    }

    fun setVoiceCommandsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            if (!enabled) {
                stopLiveVoiceSession()
                speechManager?.stopListening()
                if (_currentState.value == ZoyaState.LISTENING) {
                    _currentState.value = ZoyaState.IDLE
                }
            }
            preferencesManager.setVoiceCommandsEnabled(enabled)
        }
    }

    fun setMuted(muted: Boolean) {
        viewModelScope.launch {
            if (muted) {
                stopSpeaking()
                stopLiveVoiceSession()
            }
            preferencesManager.setMuted(muted)
        }
    }

    fun startListening() {
        val prefs = userPreferences.value
        if (!prefs.voiceCommandsEnabled) {
            _voiceErrorMessage.value = "Voice Commands band (OFF) hain Boss! Top bar se Voice ON karein."
            return
        }

        stopSpeaking()
        _liveSpeechTranscript.value = ""
        _voiceErrorMessage.value = null
        _currentState.value = ZoyaState.LISTENING

        val lang = when (prefs.voiceLanguage) {
            "Hindi" -> "hi-IN"
            "English" -> "en-IN"
            else -> "hi-IN"
        }

        speechManager?.startListening(lang)
        startLiveVoiceSession()
    }

    fun stopListeningAndProcess(simulatedSpeech: String? = null) {
        if (!simulatedSpeech.isNullOrBlank()) {
            _liveSpeechTranscript.value = simulatedSpeech
            _voiceErrorMessage.value = null
            sendVoicePrompt(simulatedSpeech)
        } else {
            stopLiveVoiceSession()
            speechManager?.stopListening()
            if (_currentState.value == ZoyaState.LISTENING) {
                _currentState.value = ZoyaState.IDLE
            }
        }
    }

    fun clearVoiceError() {
        _voiceErrorMessage.value = null
    }

    fun getSystemSpeechIntent(): android.content.Intent? {
        val lang = when (userPreferences.value.voiceLanguage) {
            "Hindi" -> "hi-IN"
            "English" -> "en-IN"
            else -> "hi-IN"
        }
        return speechManager?.createSystemSpeechIntent(lang)
    }

    fun sendVoicePrompt(promptText: String) {
        if (promptText.isBlank()) return
        _voiceErrorMessage.value = null
        _liveSpeechTranscript.value = promptText
        val prefs = userPreferences.value
        if (prefs.isMuted) {
            setMuted(false)
        }
        sendMessage(promptText)
    }

    fun updateUserName(name: String) {
        viewModelScope.launch {
            preferencesManager.updateUserName(name)
        }
    }

    fun updatePreferredTitle(title: String) {
        viewModelScope.launch {
            preferencesManager.updatePreferredTitle(title)
        }
    }

    fun toggleWakeWord(enabled: Boolean) {
        viewModelScope.launch {
            preferencesManager.setWakeWordEnabled(enabled)
        }
    }

    fun toggleMorningGreeting(enabled: Boolean) {
        viewModelScope.launch {
            preferencesManager.setMorningGreetingEnabled(enabled)
        }
    }

    fun toggleNightGreeting(enabled: Boolean) {
        viewModelScope.launch {
            preferencesManager.setNightGreetingEnabled(enabled)
        }
    }

    fun updateVoiceSpeed(speed: String) {
        viewModelScope.launch {
            preferencesManager.updateVoiceSpeed(speed)
        }
    }

    fun updateVoiceStyle(style: String) {
        viewModelScope.launch {
            preferencesManager.updateVoiceStyle(style)
        }
    }

    fun updateVoiceLanguage(language: String) {
        viewModelScope.launch {
            preferencesManager.updateVoiceLanguage(language)
        }
    }

    fun updateSelectedVoiceName(voiceName: String) {
        viewModelScope.launch {
            preferencesManager.updateSelectedVoiceName(voiceName)
        }
    }

    fun updateHumorLevel(level: String) {
        viewModelScope.launch {
            preferencesManager.updateHumorLevel(level)
        }
    }

    fun updateEmotionLevel(level: String) {
        viewModelScope.launch {
            preferencesManager.updateEmotionLevel(level)
        }
    }

    fun updateSpeakingStyle(style: String) {
        viewModelScope.launch {
            preferencesManager.updateSpeakingStyle(style)
        }
    }

    fun toggleBackgroundService(enabled: Boolean) {
        viewModelScope.launch {
            preferencesManager.setBackgroundServiceEnabled(enabled)
            val app = getApplication<Application>()
            if (enabled) {
                com.example.services.BackgroundAudioService.startService(app)
            } else {
                com.example.services.BackgroundAudioService.stopService(app)
            }
        }
    }

    fun updateCoreLongTermMemory(
        userName: String,
        preferredTitle: String,
        appCreator: String,
        personalityContext: String
    ) {
        viewModelScope.launch {
            memoryRepository.updateCorePermanentMemory(
                userName = userName,
                preferredTitle = preferredTitle,
                appCreator = appCreator,
                personalityContext = personalityContext
            )
            _coreMemory.value = memoryRepository.getCoreLongTermMemory()
        }
    }

    fun clearChat() {
        geminiSessionManager.resetSession()
        addZoyaGreeting()
    }

    fun addMemoryItem(item: String) {
        if (item.isNotBlank()) {
            _memoryItems.value = _memoryItems.value + item.trim()
        }
    }

    fun removeMemoryItem(index: Int) {
        val current = _memoryItems.value.toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            _memoryItems.value = current
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechManager?.destroy()
    }
}

