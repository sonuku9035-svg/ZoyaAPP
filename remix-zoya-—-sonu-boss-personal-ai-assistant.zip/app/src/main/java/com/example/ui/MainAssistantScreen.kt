package com.example.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.model.MessageSender
import com.example.model.ZoyaState
import com.example.ui.components.VoiceButton
import com.example.ui.components.VoiceStatus
import com.example.ui.components.ZoyaOrb
import com.example.ui.theme.ZoyaCrimson
import com.example.ui.theme.ZoyaCyanSecondary
import com.example.ui.theme.ZoyaDarkBackground
import com.example.ui.theme.ZoyaDarkCard
import com.example.ui.theme.ZoyaPinkTertiary
import com.example.ui.theme.ZoyaVioletPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAssistantScreen(
    viewModel: ZoyaViewModel,
    onNavigateToSettings: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val zoyaState by viewModel.currentState.collectAsState()
    val preferences by viewModel.userPreferences.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val liveTranscript by viewModel.liveSpeechTranscript.collectAsState()
    val rmsLevel by viewModel.rmsAudioLevel.collectAsState()
    val voiceError by viewModel.voiceErrorMessage.collectAsState()

    var showPermissionRationaleDialog by remember { mutableStateOf(false) }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            if (preferences.isMuted) {
                viewModel.setMuted(false)
            }
            viewModel.startListening()
        } else {
            showPermissionRationaleDialog = true
        }
    }

    val systemSpeechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)
            if (!matches.isNullOrEmpty()) {
                val spoken = matches[0].trim()
                if (spoken.isNotBlank()) {
                    viewModel.sendVoicePrompt(spoken)
                }
            }
        }
    }

    val launchSystemVoice: () -> Unit = {
        val intent = viewModel.getSystemSpeechIntent()
        if (intent != null) {
            try {
                systemSpeechLauncher.launch(intent)
            } catch (_: Exception) {
                viewModel.startListening()
            }
        } else {
            viewModel.startListening()
        }
    }

    // Interruption / One-Tap Voice Action
    val handleVoiceAction: () -> Unit = {
        if (preferences.isMuted) {
            // Unmute automatically when tapping microphone to speak
            viewModel.setMuted(false)
        }

        when (zoyaState) {
            ZoyaState.SPEAKING -> {
                // Interruption: Stop speaking immediately and listen for next command
                viewModel.stopSpeaking()
                val hasPermission = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                if (hasPermission) {
                    viewModel.startListening()
                } else {
                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
            ZoyaState.LISTENING -> {
                viewModel.stopListeningAndProcess()
            }
            else -> {
                val hasPermission = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED

                if (hasPermission) {
                    viewModel.startListening()
                } else {
                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
        }
    }

    val lastZoyaMessage = messages.lastOrNull { it.sender == MessageSender.ZOYA }?.text ?: ""

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        listOf(ZoyaCyanSecondary, ZoyaVioletPrimary)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SmartToy,
                                contentDescription = "ZOYA Logo",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "ZOYA",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 3.sp,
                                color = Color.White
                            )
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { onNavigateToSettings?.invoke() },
                        modifier = Modifier.testTag("top_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = Color.LightGray
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ZoyaDarkBackground
                )
            )
        },
        containerColor = ZoyaDarkBackground,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // ==========================================
            // 1. MAIN FOCUS: LARGE ANIMATED ZOYA ORB
            // ==========================================
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                ZoyaOrb(
                    state = zoyaState,
                    isMuted = preferences.isMuted,
                    size = 230.dp,
                    onClick = handleVoiceAction
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // ==========================================
            // 2. VOICE STATUS & USER LABEL
            // ==========================================
            VoiceStatus(
                state = zoyaState,
                isMuted = preferences.isMuted,
                userName = preferences.userName,
                preferredTitle = preferences.preferredTitle,
                liveTranscript = liveTranscript,
                lastSpokenText = lastZoyaMessage,
                rmsAudioLevel = rmsLevel
            )

            // Voice Error Card if any
            if (voiceError != null && zoyaState == ZoyaState.IDLE) {
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = ZoyaDarkCard),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ZoyaCrimson.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = voiceError ?: "",
                            color = Color.White,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TextButton(
                                onClick = {
                                    viewModel.clearVoiceError()
                                    handleVoiceAction()
                                }
                            ) {
                                Text("Retry Mic", color = ZoyaCyanSecondary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            TextButton(
                                onClick = {
                                    viewModel.clearVoiceError()
                                    launchSystemVoice()
                                }
                            ) {
                                Text("Google Voice", color = ZoyaPinkTertiary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Voice Suggestion Chips (One-tap voice triggers)
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val samplePrompts = listOf(
                    "Zoya kya haal hai?",
                    "Zoya mujhe hasaao 😂",
                    "Tu bahut bolti hai",
                    "Good morning Sonu Boss ☀️",
                    "Good night Sonu Boss 🌙",
                    "WhatsApp kholo",
                    "YouTube chalao",
                    "Battery batao"
                )
                items(samplePrompts) { prompt ->
                    FilterChip(
                        selected = false,
                        onClick = {
                            if (preferences.isMuted) {
                                viewModel.setMuted(false)
                            }
                            viewModel.sendVoicePrompt(prompt)
                        },
                        label = { Text(prompt, color = Color.White, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = ZoyaDarkCard
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = false,
                            borderColor = ZoyaVioletPrimary.copy(alpha = 0.4f)
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ==========================================
            // 3. VOICE CONTROLS: MICROPHONE, MUTE/UNMUTE, SETTINGS
            // ==========================================
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Large 🎙 MICROPHONE Button (VoiceButton)
                VoiceButton(
                    state = zoyaState,
                    isMuted = preferences.isMuted,
                    onClick = handleVoiceAction,
                    size = 80.dp
                )

                Text(
                    text = when {
                        zoyaState == ZoyaState.LISTENING -> "TAP TO STOP LISTENING"
                        zoyaState == ZoyaState.SPEAKING -> "TAP TO INTERRUPT ZOYA"
                        preferences.isMuted -> "TAP TO UNMUTE & SPEAK"
                        else -> "TAP TO SPEAK"
                    },
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = if (zoyaState == ZoyaState.LISTENING) ZoyaPinkTertiary else Color.LightGray,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Bottom Action Row: MUTE / UNMUTE and SETTINGS
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // MUTE / UNMUTE Button
                    Button(
                        onClick = { viewModel.toggleMute() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (preferences.isMuted) ZoyaCrimson.copy(alpha = 0.25f) else ZoyaDarkCard
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .border(
                                width = 1.dp,
                                color = if (preferences.isMuted) ZoyaCrimson else ZoyaVioletPrimary.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(16.dp)
                            )
                            .testTag("mute_unmute_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = if (preferences.isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                contentDescription = if (preferences.isMuted) "Unmute" else "Mute",
                                tint = if (preferences.isMuted) ZoyaCrimson else ZoyaCyanSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (preferences.isMuted) "MUTED" else "UNMUTED",
                                color = if (preferences.isMuted) ZoyaCrimson else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    // ⚙ SETTINGS Button
                    Button(
                        onClick = { onNavigateToSettings?.invoke() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ZoyaDarkCard
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .border(
                                width = 1.dp,
                                color = ZoyaVioletPrimary.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(16.dp)
                            )
                            .testTag("main_settings_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = ZoyaVioletPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "SETTINGS",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Microphone Permission Rationale Dialog
    if (showPermissionRationaleDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionRationaleDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Microphone Permission",
                        tint = ZoyaPinkTertiary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Microphone Permission Required", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Text(
                    text = "Sonu ${preferences.preferredTitle}, ZOYA is a voice-first assistant. It needs Android Microphone permission to capture your voice commands and talk with you. Please grant permission.",
                    color = Color.LightGray,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showPermissionRationaleDialog = false
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                ) {
                    Text("Allow Microphone", color = ZoyaCyanSecondary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showPermissionRationaleDialog = false
                        try {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", context.packageName, null)
                            }
                            context.startActivity(intent)
                        } catch (_: Exception) {}
                    }
                ) {
                    Text("App Settings", color = Color.Gray)
                }
            },
            containerColor = ZoyaDarkCard
        )
    }
}
