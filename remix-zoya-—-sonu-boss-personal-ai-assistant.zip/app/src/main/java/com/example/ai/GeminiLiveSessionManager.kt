package com.example.ai

import com.example.model.ZoyaPersonality

/**
 * Manages conversational turns, context retention, and low-latency response generation.
 */
class GeminiLiveSessionManager(
    private val geminiService: GeminiService = DefaultGeminiService()
) {

    private val conversationHistory = mutableListOf<ZoyaMessageHistory>()

    fun resetSession() {
        conversationHistory.clear()
    }

    suspend fun sendMessage(
        userMessage: String,
        userName: String = "Sonu",
        preferredTitle: String = "Boss",
        voiceStyle: String = "Cute",
        voiceLanguage: String = "Hinglish",
        appCreator: String = "Sonu Boss",
        personalityContext: String = "Sonu Boss is my creator who built me with hard work. I am Zoya, his personal AI companion.",
        customMemories: List<String> = emptyList()
    ): String {
        val reply = geminiService.generateResponse(
            prompt = userMessage,
            conversationHistory = conversationHistory,
            userName = userName,
            preferredTitle = preferredTitle,
            voiceStyle = voiceStyle,
            voiceLanguage = voiceLanguage,
            appCreator = appCreator,
            personalityContext = personalityContext,
            customMemories = customMemories
        )

        conversationHistory.add(ZoyaMessageHistory(role = "user", text = userMessage))
        conversationHistory.add(ZoyaMessageHistory(role = "model", text = reply))

        // Keep history bounded to avoid high memory/token overhead
        if (conversationHistory.size > 20) {
            val trimmed = conversationHistory.takeLast(16)
            conversationHistory.clear()
            conversationHistory.addAll(trimmed)
        }

        return reply
    }
}
