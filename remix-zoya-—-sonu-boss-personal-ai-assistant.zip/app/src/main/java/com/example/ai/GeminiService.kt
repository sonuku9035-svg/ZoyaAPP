package com.example.ai

import android.util.Log
import com.example.BuildConfig
import com.example.model.ZoyaPersonality
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ZoyaMessageHistory(
    val role: String,
    val text: String
)

/**
 * Clean Gemini AI Service handling conversational AI requests,
 * system prompt formulation, and fallback responses.
 */
interface GeminiService {
    suspend fun generateResponse(
        prompt: String,
        conversationHistory: List<ZoyaMessageHistory> = emptyList(),
        userName: String = "Sonu",
        preferredTitle: String = "Boss",
        voiceStyle: String = "Cute",
        voiceLanguage: String = "Hinglish",
        appCreator: String = "Sonu Boss",
        personalityContext: String = "Sonu Boss is my creator. I am Zoya, his smart, funny, caring personal AI companion.",
        customMemories: List<String> = emptyList()
    ): String
}

class DefaultGeminiService : GeminiService {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .build()

    override suspend fun generateResponse(
        prompt: String,
        conversationHistory: List<ZoyaMessageHistory>,
        userName: String,
        preferredTitle: String,
        voiceStyle: String,
        voiceLanguage: String,
        appCreator: String,
        personalityContext: String,
        customMemories: List<String>
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        val systemPrompt = ZoyaPersonality.getDynamicSystemPrompt(
            userName = userName,
            preferredTitle = preferredTitle,
            voiceStyle = voiceStyle,
            voiceLanguage = voiceLanguage,
            appCreator = appCreator,
            personalityContext = personalityContext,
            customMemories = customMemories
        )

        if (apiKey.isBlank()) {
            return@withContext ZoyaPersonality.getOfflineResponse(prompt, userName, preferredTitle)
        }

        val candidateModels = listOf("gemini-3.5-flash", "gemini-flash-latest")
        for (modelName in candidateModels) {
            try {
                val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"

                val contentsArray = JSONArray()

                // Conversation history (last 8 turns for latency optimization)
                val recentHistory = conversationHistory.takeLast(8)
                for (msg in recentHistory) {
                    val turnRole = if (msg.role == "user") "user" else "model"
                    contentsArray.put(JSONObject().apply {
                        put("role", turnRole)
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", msg.text) })
                        })
                    })
                }

                // Current prompt
                contentsArray.put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", prompt) })
                    })
                })

                val requestBodyJson = JSONObject().apply {
                    put("system_instruction", JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", systemPrompt) })
                        })
                    })
                    put("contents", contentsArray)
                    put("generationConfig", JSONObject().apply {
                        put("temperature", 0.7)
                        put("maxOutputTokens", 250)
                    })
                }

                val requestBody = requestBodyJson.toString()
                    .toRequestBody("application/json; charset=utf-8".toMediaType())

                val request = Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build()

                val response = okHttpClient.newCall(request).execute()
                val responseBody = response.body?.string()

                if (response.isSuccessful && !responseBody.isNullOrBlank()) {
                    val json = JSONObject(responseBody)
                    val candidates = json.optJSONArray("candidates")
                    if (candidates != null && candidates.length() > 0) {
                        val candidate = candidates.getJSONObject(0)
                        val content = candidate.optJSONObject("content")
                        val parts = content?.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            val reply = parts.getJSONObject(0).optString("text", "")
                            if (reply.isNotBlank()) {
                                return@withContext cleanReply(reply, userName, preferredTitle)
                            }
                        }
                    }
                } else {
                    Log.w("GeminiService", "API call for $modelName returned ${response.code}: $responseBody")
                }
            } catch (e: Exception) {
                Log.w("GeminiService", "Exception with $modelName: ${e.message}")
            }
        }

        return@withContext ZoyaPersonality.getOfflineResponse(prompt, userName, preferredTitle)
    }

    private fun cleanReply(reply: String, userName: String, preferredTitle: String): String {
        return reply.replace("*", "")
            .replace("#", "")
            .replace("`", "")
            .trim()
    }
}
