package com.example.ai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.util.Base64
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.BuildConfig
import com.example.model.ZoyaPersonality
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

sealed class GeminiLiveState {
    object Disconnected : GeminiLiveState()
    object Connecting : GeminiLiveState()
    object Connected : GeminiLiveState()
    object Listening : GeminiLiveState()
    object Thinking : GeminiLiveState()
    object Speaking : GeminiLiveState()
    data class Error(val message: String) : GeminiLiveState()
}

/**
 * Native Android Gemini Live WebSocket Client.
 * Implements real-time two-way voice streaming using:
 * - Official model: gemini-3.1-flash-live-preview
 * - 16kHz 16-bit Mono PCM AudioRecord microphone stream
 * - Bidirectional WebSocket (Google GenerativeService.BidiGenerateContent)
 * - 24kHz 16-bit Mono PCM AudioTrack hardware audio playback
 * - Low-latency interruption & real-time Barge-in
 */
class GeminiLiveWebSocketClient(
    private val context: Context,
    private val onStateChanged: (GeminiLiveState) -> Unit,
    private val onRmsChanged: (Float) -> Unit,
    private val onTranscriptReceived: (String, Boolean) -> Unit
) {
    companion object {
        private const val TAG = "GeminiLiveClient"
        const val LIVE_MODEL = "models/gemini-3.1-flash-live-preview"
        private const val LIVE_WS_URL =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent"

        private const val INPUT_SAMPLE_RATE = 16000
        private const val OUTPUT_SAMPLE_RATE = 24000
    }

    private val clientScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var webSocket: WebSocket? = null
    private var isConnected = false
    private var isLiveSessionActive = false
    private var isSetupComplete = false
    private var pendingTextMessage: String? = null

    // Audio recording & playback
    private var audioRecord: AudioRecord? = null
    private var recordingJob: Job? = null
    private var audioTrack: AudioTrack? = null
    private var playbackJob: Job? = null
    private val audioPlaybackQueue = ConcurrentLinkedQueue<ByteArray>()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // Indefinite for persistent WebSocket
        .writeTimeout(15, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    fun isSessionActive(): Boolean = isLiveSessionActive && isConnected

    fun startLiveSession(
        systemInstruction: String = ZoyaPersonality.getDynamicSystemPrompt(
            userName = "Sonu",
            preferredTitle = "Boss",
            voiceStyle = "Cute",
            voiceLanguage = "Hinglish",
            appCreator = "Sonu Boss",
            personalityContext = "",
            customMemories = emptyList()
        ),
        initialUserText: String? = null
    ) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank()) {
            Log.e(TAG, "Gemini API Key missing in AI Studio Secrets")
            onStateChanged(GeminiLiveState.Error("Boss, Gemini API Key missing hai! AI Studio Secrets check karein."))
            return
        }

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "Microphone permission not granted")
            onStateChanged(GeminiLiveState.Error("Boss, microphone permission nahi mili."))
            return
        }

        pendingTextMessage = initialUserText

        stopLiveSession()

        onStateChanged(GeminiLiveState.Connecting)

        val wsUrl = "$LIVE_WS_URL?key=$apiKey"
        val request = Request.Builder()
            .url(wsUrl)
            .build()

        webSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.d(TAG, "Gemini Live WebSocket Connected successfully")
                isConnected = true
                sendSetupMessage(webSocket, systemInstruction)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleServerMessage(text)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "Gemini Live WebSocket Closing: code=$code, reason=$reason")
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "Gemini Live WebSocket Closed: code=$code, reason=$reason")
                cleanupSession()
                onStateChanged(GeminiLiveState.Disconnected)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val errorMsg = t.localizedMessage ?: "Connection failed"
                Log.e(TAG, "Gemini Live WebSocket Failure: $errorMsg", t)
                cleanupSession()
                onStateChanged(GeminiLiveState.Error("Boss, Gemini connection nahi ho pa raha: $errorMsg"))
            }
        })
    }

    private fun sendSetupMessage(ws: WebSocket, systemPrompt: String) {
        try {
            val setupJson = JSONObject().apply {
                put("setup", JSONObject().apply {
                    put("model", LIVE_MODEL)
                    put("generationConfig", JSONObject().apply {
                        put("responseModalities", JSONArray().apply { put("AUDIO") })
                        put("speechConfig", JSONObject().apply {
                            put("voiceConfig", JSONObject().apply {
                                put("prebuiltVoiceConfig", JSONObject().apply {
                                    put("voiceName", "Puck") // Cheerful, natural voice for Zoya
                                })
                            })
                        })
                    })
                    put("systemInstruction", JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", systemPrompt) })
                        })
                    })
                })
            }

            ws.send(setupJson.toString())
            Log.d(TAG, "Sent Live Setup message with model $LIVE_MODEL")
            isLiveSessionActive = true
            isSetupComplete = true
            onStateChanged(GeminiLiveState.Connected)

            startAudioRecording()
            startAudioPlaybackWorker()

            // If an initial text turn was queued (e.g. quick prompt chip), send it now
            pendingTextMessage?.let { text ->
                sendTextMessage(text)
                pendingTextMessage = null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error creating setup message: ${e.message}", e)
            onStateChanged(GeminiLiveState.Error("Setup creation error: ${e.message}"))
        }
    }

    fun sendTextMessage(text: String) {
        if (text.isBlank()) return

        if (!isConnected || webSocket == null) {
            // Start session and send text once connected
            startLiveSession(initialUserText = text)
            return
        }

        try {
            onStateChanged(GeminiLiveState.Thinking)
            val clientContentJson = JSONObject().apply {
                put("clientContent", JSONObject().apply {
                    put("turns", JSONArray().apply {
                        put(JSONObject().apply {
                            put("role", "user")
                            put("parts", JSONArray().apply {
                                put(JSONObject().apply { put("text", text) })
                            })
                        })
                    })
                    put("turnComplete", true)
                })
            }

            webSocket?.send(clientContentJson.toString())
            Log.d(TAG, "Sent clientContent text turn: $text")
        } catch (e: Exception) {
            Log.e(TAG, "Error sending text message to Gemini Live: ${e.message}", e)
        }
    }

    private fun handleServerMessage(jsonText: String) {
        try {
            val json = JSONObject(jsonText)

            // Setup confirmation
            if (json.has("setupComplete")) {
                Log.d(TAG, "Gemini Live Setup acknowledged by server")
                isSetupComplete = true
                onStateChanged(GeminiLiveState.Listening)
                return
            }

            // Server Content (Audio stream & model transcript)
            val serverContent = json.optJSONObject("serverContent")
            if (serverContent != null) {
                val interrupted = serverContent.optBoolean("interrupted", false)
                if (interrupted) {
                    Log.d(TAG, "Gemini Live interrupted by user. Flushing audio queue.")
                    interruptPlayback()
                }

                val modelTurn = serverContent.optJSONObject("modelTurn")
                if (modelTurn != null) {
                    val parts = modelTurn.optJSONArray("parts")
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val part = parts.getJSONObject(i)

                            // 1. Audio data stream from Gemini
                            val inlineData = part.optJSONObject("inlineData")
                            if (inlineData != null) {
                                val mimeType = inlineData.optString("mimeType", "")
                                val base64Data = inlineData.optString("data", "")
                                if (base64Data.isNotBlank() && mimeType.startsWith("audio/pcm")) {
                                    val audioBytes = Base64.decode(base64Data, Base64.DEFAULT)
                                    audioPlaybackQueue.add(audioBytes)
                                    onStateChanged(GeminiLiveState.Speaking)
                                }
                            }

                            // 2. Transcript from Gemini
                            val text = part.optString("text", "")
                            if (text.isNotBlank()) {
                                onTranscriptReceived(text, false)
                            }
                        }
                    }
                }

                val turnComplete = serverContent.optBoolean("turnComplete", false)
                if (turnComplete) {
                    Log.d(TAG, "Model turn complete")
                    if (audioPlaybackQueue.isEmpty()) {
                        onStateChanged(GeminiLiveState.Listening)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing server message: ${e.message}", e)
        }
    }

    private fun startAudioRecording() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return
        }

        val minBufSize = AudioRecord.getMinBufferSize(
            INPUT_SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = if (minBufSize > 0) minBufSize.coerceAtLeast(4096) else 4096

        try {
            // Try VOICE_COMMUNICATION first, fallback to MIC
            var record = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                INPUT_SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )

            if (record.state != AudioRecord.STATE_INITIALIZED) {
                Log.w(TAG, "VOICE_COMMUNICATION failed to initialize, falling back to MIC")
                record.release()
                record = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    INPUT_SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
            }

            if (record.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord failed to initialize with MIC source")
                onStateChanged(GeminiLiveState.Error("Boss, microphone initialize nahi ho saka."))
                return
            }

            audioRecord = record
            audioRecord?.startRecording()
            onStateChanged(GeminiLiveState.Listening)

            recordingJob = clientScope.launch {
                val audioBuffer = ByteArray(2048)
                while (isActive && isLiveSessionActive) {
                    val readCount = audioRecord?.read(audioBuffer, 0, audioBuffer.size) ?: 0
                    if (readCount > 0) {
                        computeAndEmitRms(audioBuffer, readCount)

                        val chunkToSend = if (readCount == audioBuffer.size) audioBuffer else audioBuffer.copyOf(readCount)
                        val base64Data = Base64.encodeToString(chunkToSend, Base64.NO_WRAP)

                        val realtimeInput = JSONObject().apply {
                            put("realtimeInput", JSONObject().apply {
                                put("mediaChunks", JSONArray().apply {
                                    put(JSONObject().apply {
                                        put("mimeType", "audio/pcm;rate=$INPUT_SAMPLE_RATE")
                                        put("data", base64Data)
                                    })
                                })
                            })
                        }

                        webSocket?.send(realtimeInput.toString())
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception starting audio recording: ${e.message}", e)
            onStateChanged(GeminiLiveState.Error("Boss, mic recording start nahi ho saki: ${e.message}"))
        }
    }

    private fun startAudioPlaybackWorker() {
        val minBufSize = AudioTrack.getMinBufferSize(
            OUTPUT_SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = if (minBufSize > 0) minBufSize.coerceAtLeast(8192) else 8192

        try {
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()

            val format = AudioFormat.Builder()
                .setSampleRate(OUTPUT_SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .build()

            audioTrack = AudioTrack(
                attributes,
                format,
                bufferSize,
                AudioTrack.MODE_STREAM,
                AudioManager.AUDIO_SESSION_ID_GENERATE
            )

            audioTrack?.play()

            playbackJob = clientScope.launch {
                while (isActive) {
                    val chunk = audioPlaybackQueue.poll()
                    if (chunk != null) {
                        audioTrack?.write(chunk, 0, chunk.size)
                        computeAndEmitRms(chunk, chunk.size)
                    } else {
                        if (isLiveSessionActive && audioPlaybackQueue.isEmpty()) {
                            // Audio queue is empty
                        }
                        delay(10)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing AudioTrack: ${e.message}", e)
        }
    }

    private fun computeAndEmitRms(buffer: ByteArray, size: Int) {
        if (size <= 0) return
        var sum = 0.0
        val sampleCount = size / 2
        for (i in 0 until size step 2) {
            if (i + 1 < size) {
                val sample = ((buffer[i + 1].toInt() shl 8) or (buffer[i].toInt() and 0xFF)).toShort()
                sum += (sample * sample).toDouble()
            }
        }
        val rms = sqrt(sum / sampleCount.coerceAtLeast(1))
        val normalized = (rms / 16384.0).toFloat().coerceIn(0f, 1f)
        onRmsChanged(normalized)
    }

    fun interruptPlayback() {
        audioPlaybackQueue.clear()
        try {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.play()
        } catch (e: Exception) {
            Log.w(TAG, "Error flushing AudioTrack: ${e.message}")
        }
    }

    fun stopLiveSession() {
        cleanupSession()
        webSocket?.close(1000, "Session ended by user")
        webSocket = null
        isConnected = false
        isLiveSessionActive = false
        isSetupComplete = false
        onStateChanged(GeminiLiveState.Disconnected)
    }

    private fun cleanupSession() {
        isLiveSessionActive = false
        isSetupComplete = false
        recordingJob?.cancel()
        recordingJob = null

        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null

        playbackJob?.cancel()
        playbackJob = null

        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (_: Exception) {}
        audioTrack = null
        audioPlaybackQueue.clear()
    }
}
