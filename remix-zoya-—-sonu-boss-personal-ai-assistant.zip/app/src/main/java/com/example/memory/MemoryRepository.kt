package com.example.memory

import android.content.Context
import com.example.data.PreferencesManager
import com.example.data.UserPreferences
import com.example.db.MemoryDao
import com.example.db.MemoryEntity
import com.example.db.ZoyaDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

data class CoreLongTermMemory(
    val userName: String = "Sonu",
    val preferredTitle: String = "Boss",
    val appCreator: String = "Sonu Boss",
    val personalityContext: String = "Sonu Boss is my creator who built me with hard work. I am Zoya, his personal AI companion.",
    val customMemories: List<MemoryEntity> = emptyList()
)

class MemoryRepository(
    private val memoryDao: MemoryDao,
    private val preferencesManager: PreferencesManager
) {
    val allMemories: Flow<List<MemoryEntity>> = memoryDao.getAllMemories()
    val userPreferencesFlow: Flow<UserPreferences> = preferencesManager.userPreferencesFlow

    suspend fun initCorePermanentMemories() {
        val existing = memoryDao.getMemoriesByCategory("Core Permanent").first()
        if (existing.isEmpty()) {
            val defaultCoreFacts = listOf(
                MemoryEntity(
                    fact = "User Name: Sonu",
                    category = "Core Permanent",
                    timestamp = System.currentTimeMillis()
                ),
                MemoryEntity(
                    fact = "Preferred Title: Boss",
                    category = "Core Permanent",
                    timestamp = System.currentTimeMillis()
                ),
                MemoryEntity(
                    fact = "App Creator: Sonu Boss",
                    category = "Core Permanent",
                    timestamp = System.currentTimeMillis()
                ),
                MemoryEntity(
                    fact = "Personality Context: Sonu Boss is my creator who built me with hard work. I am Zoya, his personal AI companion.",
                    category = "Core Permanent",
                    timestamp = System.currentTimeMillis()
                )
            )
            defaultCoreFacts.forEach { memoryDao.insertMemory(it) }
        }
    }

    suspend fun getCoreLongTermMemory(): CoreLongTermMemory {
        initCorePermanentMemories()
        val prefs = preferencesManager.userPreferencesFlow.first()
        val coreList = memoryDao.getMemoriesByCategory("Core Permanent").first()
        val customList = memoryDao.getMemoriesByCategory("User Fact").first()

        val appCreatorFact = coreList.find { it.fact.startsWith("App Creator:") }?.fact?.substringAfter("App Creator:")?.trim()
            ?: "Sonu Boss"
        val personalityContextFact = coreList.find { it.fact.startsWith("Personality Context:") }?.fact?.substringAfter("Personality Context:")?.trim()
            ?: "Sonu Boss is my creator who built me with hard work. I am Zoya, his personal AI companion."

        return CoreLongTermMemory(
            userName = prefs.userName,
            preferredTitle = prefs.preferredTitle,
            appCreator = appCreatorFact,
            personalityContext = personalityContextFact,
            customMemories = customList
        )
    }

    suspend fun updateCorePermanentMemory(
        userName: String,
        preferredTitle: String,
        appCreator: String,
        personalityContext: String
    ) {
        preferencesManager.updateUserName(userName)
        preferencesManager.updatePreferredTitle(preferredTitle)

        memoryDao.deleteMemoriesByCategory("Core Permanent")
        val updatedCoreFacts = listOf(
            MemoryEntity(
                fact = "User Name: $userName",
                category = "Core Permanent",
                timestamp = System.currentTimeMillis()
            ),
            MemoryEntity(
                fact = "Preferred Title: $preferredTitle",
                category = "Core Permanent",
                timestamp = System.currentTimeMillis()
            ),
            MemoryEntity(
                fact = "App Creator: $appCreator",
                category = "Core Permanent",
                timestamp = System.currentTimeMillis()
            ),
            MemoryEntity(
                fact = "Personality Context: $personalityContext",
                category = "Core Permanent",
                timestamp = System.currentTimeMillis()
            )
        )
        updatedCoreFacts.forEach { memoryDao.insertMemory(it) }
    }

    suspend fun saveMemory(memory: MemoryEntity) {
        if (memory.id == 0) {
            memoryDao.insertMemory(memory)
        } else {
            memoryDao.updateMemory(memory)
        }
    }

    suspend fun deleteMemory(memory: MemoryEntity) {
        memoryDao.deleteMemory(memory)
    }

    suspend fun clearAllCustomMemories() {
        memoryDao.deleteMemoriesByCategory("User Fact")
    }

    companion object {
        fun create(context: Context): MemoryRepository {
            val db = ZoyaDatabase.getInstance(context)
            val prefs = PreferencesManager(context)
            return MemoryRepository(db.memoryDao(), prefs)
        }
    }
}
