package com.example.memory

import android.content.Context
import com.example.db.MemoryDao
import com.example.db.MemoryEntity
import com.example.db.ZoyaDatabase
import kotlinx.coroutines.flow.Flow

data class MemoryProcessResult(
    val handled: Boolean,
    val feedbackMessage: String
)

class MemoryManager(private val memoryDao: MemoryDao) {

    val allMemories: Flow<List<MemoryEntity>> = memoryDao.getAllMemories()

    suspend fun processExplicitMemoryCommand(input: String, title: String = "Boss"): MemoryProcessResult {
        val lower = input.lowercase().trim()

        // Explicit instruction check: "yaad rakhna", "yaad rakho", "note kar lo", "remember that"
        val isExplicitTeaching = lower.contains("yaad rakhna") ||
                lower.contains("yaad rakho") ||
                lower.contains("note kar lo") ||
                lower.contains("remember")

        if (isExplicitTeaching) {
            val factContent = extractFactContent(input)
            if (factContent.isNotBlank()) {
                val memory = MemoryEntity(
                    fact = factContent,
                    category = "User Fact",
                    timestamp = System.currentTimeMillis()
                )
                memoryDao.insertMemory(memory)
                return MemoryProcessResult(
                    handled = true,
                    feedbackMessage = "Ji $title! Maine ye baat strictly yaad kar li hai: \"$factContent\""
                )
            }
        }

        return MemoryProcessResult(handled = false, feedbackMessage = "")
    }

    private fun extractFactContent(input: String): String {
        return input.replace("zoya", "", ignoreCase = true)
            .replace("ye yaad rakhna", "", ignoreCase = true)
            .replace("ye yaad rakho", "", ignoreCase = true)
            .replace("yaad rakhna", "", ignoreCase = true)
            .replace("yaad rakho", "", ignoreCase = true)
            .replace("note kar lo", "", ignoreCase = true)
            .replace("remember that", "", ignoreCase = true)
            .replace("remember", "", ignoreCase = true)
            .trim()
            .trim(':', ',', '.', '-')
    }

    suspend fun saveMemory(memory: MemoryEntity) {
        if (memory.id == 0) {
            memoryDao.insertMemory(memory)
        } else {
            memoryDao.updateMemory(memory)
        }
    }

    suspend fun deleteMemory(memory: MemoryEntity) {
        memoryDao.deleteMemory(memory)
    }

    suspend fun deleteAllMemories() {
        memoryDao.deleteAllMemories()
    }

    companion object {
        fun create(context: Context): MemoryManager {
            val db = ZoyaDatabase.getInstance(context)
            return MemoryManager(db.memoryDao())
        }
    }
}
