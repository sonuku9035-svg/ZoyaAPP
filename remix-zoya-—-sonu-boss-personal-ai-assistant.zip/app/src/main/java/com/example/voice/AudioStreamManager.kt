package com.example.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * AudioStreamManager manages audio focus, audio stream volume levels,
 * and real-time audio analysis for Zoya's voice processing.
 */
class AudioStreamManager(private val context: Context) {

    private val audioManager: AudioManager =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _audioRmsLevel = MutableStateFlow(0f)
    val audioRmsLevel: StateFlow<Float> = _audioRmsLevel.asStateFlow()

    private val _isAudioStreaming = MutableStateFlow(false)
    val isAudioStreaming: StateFlow<Boolean> = _isAudioStreaming.asStateFlow()

    private var audioFocusRequest: AudioFocusRequest? = null

    /**
     * Requests transient audio focus so Zoya voice output/listening is clean
     * and ducks other background audio.
     */
    fun requestVoiceAudioFocus(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val playbackAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()

                val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(playbackAttributes)
                    .setAcceptsDelayedFocusGain(false)
                    .setOnAudioFocusChangeListener { focusChange ->
                        if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                            Log.d("AudioStreamManager", "Audio focus lost")
                        }
                    }
                    .build()

                audioFocusRequest = request
                audioManager.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            } else {
                @Suppress("DEPRECATION")
                audioManager.requestAudioFocus(
                    null,
                    AudioManager.STREAM_VOICE_CALL,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            }
        } catch (e: Exception) {
            Log.e("AudioStreamManager", "Error requesting audio focus: ${e.message}")
            true
        }
    }

    /**
     * Releases audio focus back to the system.
     */
    fun abandonVoiceAudioFocus() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
                audioFocusRequest = null
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(null)
            }
        } catch (e: Exception) {
            Log.e("AudioStreamManager", "Error abandoning audio focus: ${e.message}")
        }
    }

    /**
     * Updates RMS dB level to a normalized [0.0f..1.0f] value for UI waveform rendering.
     */
    fun updateRmsDb(rmsdB: Float) {
        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
        _audioRmsLevel.value = normalized
    }

    /**
     * Computes RMS directly from raw PCM 16-bit audio buffer for live streaming audio.
     */
    fun processAudioBuffer(buffer: ByteArray, readSize: Int) {
        if (readSize <= 0) return
        var sum = 0.0
        val sampleCount = readSize / 2
        for (i in 0 until readSize step 2) {
            if (i + 1 < readSize) {
                val sample = ((buffer[i + 1].toInt() shl 8) or (buffer[i].toInt() and 0xFF)).toShort()
                sum += (sample * sample).toDouble()
            }
        }
        val rms = sqrt(sum / sampleCount.coerceAtLeast(1))
        val normalized = (rms / 32767.0).toFloat().coerceIn(0f, 1f)
        _audioRmsLevel.value = normalized
    }

    fun setStreamingState(isStreaming: Boolean) {
        _isAudioStreaming.value = isStreaming
        if (!isStreaming) {
            _audioRmsLevel.value = 0f
        }
    }
}
