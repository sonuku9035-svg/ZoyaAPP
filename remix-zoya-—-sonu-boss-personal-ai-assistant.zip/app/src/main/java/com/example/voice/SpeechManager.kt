package com.example.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.content.ContextCompat
import java.util.Locale

data class PendingSpeechRequest(
    val text: String,
    val speed: String,
    val style: String,
    val onStart: (() -> Unit)?,
    val onDone: (() -> Unit)?
)

class SpeechManager(
    private val context: Context,
    private val onSpeechResult: (String) -> Unit,
    private val onSpeechPartialResult: (String) -> Unit,
    private val onSpeechListeningStateChanged: (Boolean) -> Unit,
    private val onRmsChangedCallback: ((Float) -> Unit)? = null,
    private val onError: (String) -> Unit
) : TextToSpeech.OnInitListener {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false
    private var isListening = false
    private var pendingSpeech: PendingSpeechRequest? = null

    private var onTtsStartCallback: (() -> Unit)? = null
    private var onTtsDoneCallback: (() -> Unit)? = null

    init {
        mainHandler.post {
            initSpeechRecognizer()
        }
        textToSpeech = TextToSpeech(context.applicationContext, this)
    }

    fun hasRecordAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun isSpeechRecognitionAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    fun createSystemSpeechIntent(language: String = "hi-IN"): Intent {
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Sonu Boss, ZOYA ko boliye...")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
    }

    private fun initSpeechRecognizer() {
        try {
            if (speechRecognizer != null) {
                try { speechRecognizer?.destroy() } catch (_: Exception) {}
                speechRecognizer = null
            }

            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context.applicationContext).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        isListening = true
                        mainHandler.post { onSpeechListeningStateChanged(true) }
                    }

                    override fun onBeginningOfSpeech() {
                        isListening = true
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                        mainHandler.post { onRmsChangedCallback?.invoke(normalized) }
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        isListening = false
                        mainHandler.post { onSpeechListeningStateChanged(false) }
                    }

                    override fun onError(error: Int) {
                        isListening = false
                        mainHandler.post {
                            onSpeechListeningStateChanged(false)
                            val errorMessage = when (error) {
                                SpeechRecognizer.ERROR_NO_MATCH -> "Kuch sunaai nahi diya Boss! Dobara bolein ya chip tap karein."
                                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Boliye Boss, main sun rahi hoon!"
                                SpeechRecognizer.ERROR_AUDIO -> "Audio recording issue, Boss"
                                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required, Boss!"
                                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Mic busy tha, ab boliye Boss"
                                SpeechRecognizer.ERROR_NETWORK -> "Network check karein Boss"
                                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Voice timeout, dobara boliye Boss"
                                SpeechRecognizer.ERROR_CLIENT -> "Voice client ready (Dobara mic dabayein)"
                                SpeechRecognizer.ERROR_SERVER -> "Voice server busy"
                                else -> "Voice issue ($error)"
                            }
                            onError(errorMessage)
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        isListening = false
                        mainHandler.post { onSpeechListeningStateChanged(false) }
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            val topMatch = matches[0].trim()
                            if (topMatch.isNotBlank()) {
                                mainHandler.post { onSpeechResult(topMatch) }
                            } else {
                                mainHandler.post { onError("Boliye Boss, main sun rahi hoon!") }
                            }
                        } else {
                            mainHandler.post { onError("Boliye Boss, main sun rahi hoon!") }
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            mainHandler.post { onSpeechPartialResult(matches[0]) }
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        } catch (e: Exception) {
            Log.e("SpeechManager", "Failed to initialize SpeechRecognizer", e)
        }
    }

    fun startListening(language: String = "hi-IN") {
        mainHandler.post {
            stopSpeaking()

            if (!hasRecordAudioPermission()) {
                isListening = false
                onSpeechListeningStateChanged(false)
                onError("Microphone permission chahiye Boss!")
                return@post
            }

            if (speechRecognizer == null) {
                initSpeechRecognizer()
            }

            if (speechRecognizer == null) {
                isListening = false
                onSpeechListeningStateChanged(false)
                onError("Speech service active nahi hai. Quick commands tap karein ya dobara mic dabayein!")
                return@post
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language)
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 4000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
            }

            try {
                speechRecognizer?.startListening(intent)
                isListening = true
                onSpeechListeningStateChanged(true)
            } catch (e: Exception) {
                isListening = false
                onSpeechListeningStateChanged(false)
                onError("Mic start nahi hua: ${e.localizedMessage}")
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            if (isListening) {
                try {
                    speechRecognizer?.stopListening()
                } catch (e: Exception) {
                    Log.e("SpeechManager", "Error stopping listening", e)
                }
                isListening = false
                onSpeechListeningStateChanged(false)
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            try {
                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                textToSpeech?.setAudioAttributes(audioAttributes)
            } catch (e: Exception) {
                Log.w("SpeechManager", "Failed to set audio attributes", e)
            }

            val result = textToSpeech?.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                val enInResult = textToSpeech?.setLanguage(Locale("en", "IN"))
                if (enInResult == TextToSpeech.LANG_MISSING_DATA || enInResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    val defaultResult = textToSpeech?.setLanguage(Locale.getDefault())
                    if (defaultResult == TextToSpeech.LANG_MISSING_DATA || defaultResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        textToSpeech?.setLanguage(Locale.US)
                    }
                }
            }

            // Attempt to select a sweet female voice if available
            try {
                val voices = textToSpeech?.voices
                val femaleVoice = voices?.firstOrNull { voice ->
                    val name = voice.name.lowercase()
                    (name.contains("female") || name.contains("hi_in") || name.contains("hi-in") || name.contains("en_in") || name.contains("en-in")) && !voice.isNetworkConnectionRequired
                }
                if (femaleVoice != null) {
                    textToSpeech?.voice = femaleVoice
                }
            } catch (_: Exception) {}

            // ZOYA's original natural sweet voice parameters
            textToSpeech?.setPitch(1.05f)
            textToSpeech?.setSpeechRate(1.0f)

            textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    mainHandler.post { onTtsStartCallback?.invoke() }
                }

                override fun onDone(utteranceId: String?) {
                    mainHandler.post { onTtsDoneCallback?.invoke() }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    mainHandler.post { onTtsDoneCallback?.invoke() }
                }
            })

            isTtsInitialized = true

            // Play queued pending speech if requested before TTS finished init
            pendingSpeech?.let { req ->
                pendingSpeech = null
                speak(req.text, req.speed, req.style, req.onStart, req.onDone)
            }
        } else {
            Log.e("SpeechManager", "TTS initialization failed status: $status")
        }
    }

    private fun cleanTextForTts(text: String): String {
        return text.replace(Regex("[*_#~`>+\\-•]"), "")
            .replace(Regex("[\uD83C-\uDBFF\uDC00-\uDFFF]"), "") // Clean emojis for smoother TTS
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun updateVoiceParameters(
        speed: String = "Normal",
        style: String = "Normal"
    ) {
        if (!isTtsInitialized || textToSpeech == null) return

        val rate = when (speed) {
            "Slow" -> 0.85f
            "Fast" -> 1.15f
            else -> 1.0f
        }

        val pitch = when (style) {
            "Cute" -> 1.05f
            "Funny" -> 1.05f
            "Friendly" -> 1.02f
            "Calm" -> 0.98f
            "Expressive" -> 1.05f
            else -> 1.05f // ZOYA's original natural sweet voice
        }

        try {
            textToSpeech?.setSpeechRate(rate)
            textToSpeech?.setPitch(pitch)
        } catch (e: Exception) {
            Log.e("SpeechManager", "Error updating voice parameters", e)
        }
    }

    fun speak(
        text: String,
        speed: String = "Normal",
        style: String = "Normal",
        onStart: (() -> Unit)? = null,
        onDone: (() -> Unit)? = null
    ) {
        if (!isTtsInitialized || textToSpeech == null) {
            pendingSpeech = PendingSpeechRequest(text, speed, style, onStart, onDone)
            return
        }

        stopSpeaking()
        updateVoiceParameters(speed, style)

        onTtsStartCallback = onStart
        onTtsDoneCallback = onDone

        val cleaned = cleanTextForTts(text)
        if (cleaned.isBlank()) {
            onDone?.invoke()
            return
        }

        val utteranceId = "ZOYA_SPEECH_${System.currentTimeMillis()}"
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        }
        val result = textToSpeech?.speak(cleaned, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        if (result == TextToSpeech.ERROR) {
            @Suppress("DEPRECATION")
            val fallbackMap = HashMap<String, String>().apply {
                put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
            }
            textToSpeech?.speak(cleaned, TextToSpeech.QUEUE_FLUSH, fallbackMap)
        }
    }

    fun stopSpeaking() {
        try {
            if (textToSpeech?.isSpeaking == true) {
                textToSpeech?.stop()
                onTtsDoneCallback?.invoke()
            }
        } catch (e: Exception) {
            Log.e("SpeechManager", "Error stopping TTS", e)
        }
    }

    fun isSpeaking(): Boolean {
        return textToSpeech?.isSpeaking == true
    }

    fun destroy() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            textToSpeech = null
        } catch (e: Exception) {
            Log.e("SpeechManager", "Error destroying speech manager", e)
        }
    }
}

