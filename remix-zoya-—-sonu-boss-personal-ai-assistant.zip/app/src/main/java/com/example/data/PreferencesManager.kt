package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "zoya_preferences")

data class UserPreferences(
    val userName: String = "Sonu",
    val preferredTitle: String = "Boss",
    val wakeWordEnabled: Boolean = true,
    val morningGreetingEnabled: Boolean = true,
    val nightGreetingEnabled: Boolean = true,
    val morningTime: String = "07:00",
    val nightTime: String = "22:00",
    val isFirstTimeSetup: Boolean = true,
    val voiceSpeed: String = "Normal",
    val voiceStyle: String = "Cute",
    val voiceLanguage: String = "Hinglish",
    val selectedVoiceName: String = "Default Synthetic Female",
    val humorLevel: String = "Funny",
    val emotionLevel: String = "Expressive",
    val speakingStyle: String = "Hinglish",
    val isBackgroundServiceEnabled: Boolean = false,
    val voiceCommandsEnabled: Boolean = true,
    val isMuted: Boolean = false
)

class PreferencesManager(private val context: Context) {

    companion object {
        private val KEY_USER_NAME = stringPreferencesKey("user_name")
        private val KEY_PREFERRED_TITLE = stringPreferencesKey("preferred_title")
        private val KEY_WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
        private val KEY_MORNING_GREETING_ENABLED = booleanPreferencesKey("morning_greeting_enabled")
        private val KEY_NIGHT_GREETING_ENABLED = booleanPreferencesKey("night_greeting_enabled")
        private val KEY_MORNING_TIME = stringPreferencesKey("morning_time")
        private val KEY_NIGHT_TIME = stringPreferencesKey("night_time")
        private val KEY_IS_FIRST_TIME_SETUP = booleanPreferencesKey("is_first_time_setup")
        private val KEY_VOICE_SPEED = stringPreferencesKey("voice_speed")
        private val KEY_VOICE_STYLE = stringPreferencesKey("voice_style")
        private val KEY_VOICE_LANGUAGE = stringPreferencesKey("voice_language")
        private val KEY_SELECTED_VOICE_NAME = stringPreferencesKey("selected_voice_name")
        private val KEY_HUMOR_LEVEL = stringPreferencesKey("humor_level")
        private val KEY_EMOTION_LEVEL = stringPreferencesKey("emotion_level")
        private val KEY_SPEAKING_STYLE = stringPreferencesKey("speaking_style")
        private val KEY_BACKGROUND_SERVICE_ENABLED = booleanPreferencesKey("background_service_enabled")
        private val KEY_VOICE_COMMANDS_ENABLED = booleanPreferencesKey("voice_commands_enabled")
        private val KEY_IS_MUTED = booleanPreferencesKey("is_muted")
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { preferences ->
        UserPreferences(
            userName = preferences[KEY_USER_NAME] ?: "Sonu",
            preferredTitle = preferences[KEY_PREFERRED_TITLE] ?: "Boss",
            wakeWordEnabled = preferences[KEY_WAKE_WORD_ENABLED] ?: true,
            morningGreetingEnabled = preferences[KEY_MORNING_GREETING_ENABLED] ?: true,
            nightGreetingEnabled = preferences[KEY_NIGHT_GREETING_ENABLED] ?: true,
            morningTime = preferences[KEY_MORNING_TIME] ?: "07:00",
            nightTime = preferences[KEY_NIGHT_TIME] ?: "22:00",
            isFirstTimeSetup = preferences[KEY_IS_FIRST_TIME_SETUP] ?: true,
            voiceSpeed = preferences[KEY_VOICE_SPEED] ?: "Normal",
            voiceStyle = preferences[KEY_VOICE_STYLE] ?: "Cute",
            voiceLanguage = preferences[KEY_VOICE_LANGUAGE] ?: "Hinglish",
            selectedVoiceName = preferences[KEY_SELECTED_VOICE_NAME] ?: "Default Synthetic Female",
            humorLevel = preferences[KEY_HUMOR_LEVEL] ?: "Funny",
            emotionLevel = preferences[KEY_EMOTION_LEVEL] ?: "Expressive",
            speakingStyle = preferences[KEY_SPEAKING_STYLE] ?: "Hinglish",
            isBackgroundServiceEnabled = preferences[KEY_BACKGROUND_SERVICE_ENABLED] ?: false,
            voiceCommandsEnabled = preferences[KEY_VOICE_COMMANDS_ENABLED] ?: true,
            isMuted = preferences[KEY_IS_MUTED] ?: false
        )
    }

    suspend fun updateUserName(name: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_USER_NAME] = name
        }
    }

    suspend fun updatePreferredTitle(title: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_PREFERRED_TITLE] = title
        }
    }

    suspend fun setWakeWordEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_WAKE_WORD_ENABLED] = enabled
        }
    }

    suspend fun setMorningGreetingEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_MORNING_GREETING_ENABLED] = enabled
        }
    }

    suspend fun setNightGreetingEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_NIGHT_GREETING_ENABLED] = enabled
        }
    }

    suspend fun updateMorningTime(time: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_MORNING_TIME] = time
        }
    }

    suspend fun updateNightTime(time: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_NIGHT_TIME] = time
        }
    }

    suspend fun setFirstTimeSetupCompleted(completed: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_IS_FIRST_TIME_SETUP] = !completed
        }
    }

    suspend fun updateVoiceSpeed(speed: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_VOICE_SPEED] = speed
        }
    }

    suspend fun updateVoiceStyle(style: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_VOICE_STYLE] = style
        }
    }

    suspend fun updateVoiceLanguage(language: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_VOICE_LANGUAGE] = language
        }
    }

    suspend fun updateSelectedVoiceName(voiceName: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_SELECTED_VOICE_NAME] = voiceName
        }
    }

    suspend fun updateHumorLevel(level: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_HUMOR_LEVEL] = level
        }
    }

    suspend fun updateEmotionLevel(level: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_EMOTION_LEVEL] = level
        }
    }

    suspend fun updateSpeakingStyle(style: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_SPEAKING_STYLE] = style
        }
    }

    suspend fun setBackgroundServiceEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_BACKGROUND_SERVICE_ENABLED] = enabled
        }
    }

    suspend fun setVoiceCommandsEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_VOICE_COMMANDS_ENABLED] = enabled
        }
    }

    suspend fun setMuted(muted: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_IS_MUTED] = muted
        }
    }
}
