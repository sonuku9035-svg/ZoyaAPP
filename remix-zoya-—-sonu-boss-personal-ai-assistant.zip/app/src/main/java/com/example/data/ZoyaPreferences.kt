package com.example.data

import android.content.Context

/**
 * Typealias and helper for ZoyaPreferences.
 */
typealias ZoyaPreferences = PreferencesManager

fun createZoyaPreferences(context: Context): PreferencesManager = PreferencesManager(context)
