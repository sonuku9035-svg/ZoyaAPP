package com.example.data

/**
 * Domain model representing Voice Settings configuration.
 */
data class VoiceSettings(
    val voiceSpeed: String = "Normal",
    val voiceStyle: String = "Cute",
    val voiceLanguage: String = "Hinglish",
    val selectedVoiceName: String = "Default Synthetic Female",
    val humorLevel: String = "Funny",
    val emotionLevel: String = "Expressive",
    val speakingStyle: String = "Hinglish",
    val wakeWordEnabled: Boolean = true,
    val morningGreetingEnabled: Boolean = true,
    val nightGreetingEnabled: Boolean = true,
    val isMuted: Boolean = false
)
