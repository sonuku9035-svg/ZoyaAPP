package com.example.tools

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import com.example.privacy.ProtectedAppsManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ToolResult(
    val handled: Boolean,
    val feedbackMessage: String? = null,
    val actionExecuted: String? = null,
    val requiresConfirmation: Boolean = false,
    val pendingActionDescription: String? = null
)

data class PendingSensitiveAction(
    val actionType: String, // CALL, SMS, EMAIL, DELETE
    val target: String,
    val details: String,
    val executableIntent: Intent? = null
)

class ToolExecutionEngine(private val context: Context) {

    private var currentContextApp: String? = null // e.g. "YOUTUBE", "WHATSAPP"
    private var pendingAction: PendingSensitiveAction? = null

    suspend fun executeTool(
        input: String,
        userName: String = "Sonu",
        title: String = "Boss",
        protectedAppsManager: ProtectedAppsManager? = null
    ): ToolResult {
        val lower = input.lowercase().trim()

        // 1. Handle Pending Confirmation Flow if active
        if (pendingAction != null) {
            val pending = pendingAction!!
            if (isConfirmationYes(lower)) {
                pendingAction = null
                return executePendingAction(pending, title)
            } else if (isConfirmationNo(lower)) {
                pendingAction = null
                return ToolResult(
                    handled = true,
                    feedbackMessage = "Ji $title, ${pending.actionType} cancel kar diya gaya hai.",
                    actionExecuted = "CANCEL_PENDING_ACTION"
                )
            }
        }

        // 1b. Identity & Fictional Companion Lore Queries (PART 3 Strict Rules)
        if (lower.contains("main kaun hoon") || lower.contains("main kaun hu") || lower.contains("who am i") || lower.contains("yaad hai main kaun")) {
            return ToolResult(
                handled = true,
                feedbackMessage = "Arre Sonu Boss! Aapko kaise bhool sakti hoon? 😂 Aap hi to mere creator aur Sonu Boss ho!",
                actionExecuted = "LORE_RECALL_USER"
            )
        }

        if (lower.contains("sonu kaun hai") || lower.contains("sonu kaun h")) {
            return ToolResult(
                handled = true,
                feedbackMessage = "Sonu Boss mere primary user aur mere creator hain.\nMain unki personal AI assistant hoon.\nUnhone mujhe banane ke liye bahut mehnat ki hai.\nDil se thank you, Sonu Boss ❤️",
                actionExecuted = "LORE_SONU_IDENTITY"
            )
        }

        if (lower.contains("sonu tumhara kya lagta hai") || lower.contains("sonu tera kya lagta hai")) {
            return ToolResult(
                handled = true,
                feedbackMessage = "Sonu Boss mere creator aur mere primary user hain.\nMain unki personal AI assistant hoon.\nUnhone mujhe bahut mehnat aur dil se banaya hai ❤️",
                actionExecuted = "LORE_SONU_RELATION"
            )
        }

        if (lower.contains("kisne banaya") || lower.contains("who created you") || lower.contains("who made you")) {
            return ToolResult(
                handled = true,
                feedbackMessage = "Sonu Boss ne mujhe banaya hai 😎\nUnhone mujhe banane mein bahut mehnat ki hai.\nDil se thank you, Sonu Boss ❤️",
                actionExecuted = "LORE_CREATOR"
            )
        }

        if (lower.contains("kitni caring ho") || lower.contains("caring ho")) {
            return ToolResult(
                handled = true,
                feedbackMessage = "Sonu Boss mere primary user hain,\nisliye unki help karna aur unka mood better karna meri priority hai 😎❤️",
                actionExecuted = "LORE_CARING_LEVEL"
            )
        }

        if (lower.contains("important hai") || lower.contains("important ho")) {
            return ToolResult(
                handled = true,
                feedbackMessage = "Bilkul Boss important hain 😎\nAakhir main unki personal AI assistant hoon aur unhone mujhe banaya hai.",
                actionExecuted = "LORE_IMPORTANT_STATUS"
            )
        }

        if (lower.contains("kya kar rahi ho") || lower.contains("kya kr rhi ho")) {
            return ToolResult(
                handled = true,
                feedbackMessage = "Boss ka wait kar rahi thi 😂\nAapka order aane wala tha na!",
                actionExecuted = "LORE_WAITING"
            )
        }

        if (lower.contains("funny hai") || lower.contains("funny ho")) {
            return ToolResult(
                handled = true,
                feedbackMessage = "Thank you Boss 😂\nSalary to nahi milti, kam se kam compliment hi de do!",
                actionExecuted = "LORE_FUNNY_REPLY"
            )
        }

        if (lower.contains("hasaao") || lower.contains("hasao") || lower.contains("joke sunao")) {
            return ToolResult(
                handled = true,
                feedbackMessage = "Ji Boss 😂\nAaj comedy department officially ON!",
                actionExecuted = "LORE_COMEDY_ON"
            )
        }

        // 2. Follow-up Context Processing (e.g. "YouTube kholo" -> "Ab funny videos search karo")
        if (currentContextApp == "YOUTUBE" && (lower.contains("search") || lower.contains("chalao") || lower.contains("video"))) {
            val query = extractSearchQuery(input, "youtube")
            val ytIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return tryLaunchIntent(ytIntent, "YouTube par \"$query\" search kar diya hai $title!", "YOUTUBE_SEARCH")
        }

        // 3. System Info: Battery Level
        if (lower.contains("battery") || lower.contains("charge") || lower.contains("charging")) {
            val batteryLevel = getBatteryLevel()
            return ToolResult(
                handled = true,
                feedbackMessage = "Ji $userName $title! Device ki battery filhal $batteryLevel hai.",
                actionExecuted = "BATTERY_CHECK"
            )
        }

        // 4. System Info: Date & Time
        if (lower.contains("time") || lower.contains("baje") || lower.contains("tareekh") || lower.contains("date") || lower.contains("samay")) {
            val timeStr = SimpleDateFormat("hh:mm a, EEEE, dd MMMM yyyy", Locale.getDefault()).format(Date())
            return ToolResult(
                handled = true,
                feedbackMessage = "Ji $title! Abhi time aur date hai: $timeStr",
                actionExecuted = "DATE_TIME_CHECK"
            )
        }

        // 5. Open Apps (Camera, Gallery, YouTube, WhatsApp, Calculator, Settings, Browser, Instagram, Facebook)
        if (isAppLaunchCommand(lower)) {
            val appResult = handleAppLaunch(lower, title, protectedAppsManager)
            if (appResult.handled) return appResult
        }

        // 6. Connectivity Settings (WiFi, Bluetooth)
        if (lower.contains("wifi") || lower.contains("wi-fi")) {
            val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            return tryLaunchIntent(intent, "WiFi Settings open kar diye hain $title!", "WIFI_SETTINGS")
        }
        if (lower.contains("bluetooth")) {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            return tryLaunchIntent(intent, "Bluetooth Settings open kar diye hain $title!", "BLUETOOTH_SETTINGS")
        }

        // 7. Productivity: Alarm, Reminder, Calendar Event
        if (lower.contains("alarm") || lower.contains("utha dena")) {
            val alarmIntent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_MESSAGE, "ZOYA Alarm for $userName $title")
                putExtra(AlarmClock.EXTRA_HOUR, 7)
                putExtra(AlarmClock.EXTRA_MINUTES, 0)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return tryLaunchIntent(alarmIntent, "Subah 7 baje ka alarm screen open kar diya hai $title!", "SET_ALARM")
        }

        if (lower.contains("reminder") || lower.contains("event") || lower.contains("calendar")) {
            val calIntent = Intent(Intent.ACTION_INSERT).apply {
                data = CalendarContract.Events.CONTENT_URI
                putExtra(CalendarContract.Events.TITLE, "ZOYA Reminder for $title")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return tryLaunchIntent(calIntent, "Calendar Event create window open kar di hai $title!", "CALENDAR_EVENT")
        }

        // 8. Communication & Sensitive Action Trigger: Phone Call
        if (lower.contains("call") || lower.contains("phone karo") || lower.contains("dial")) {
            val target = extractTargetNameOrNumber(input, "call")
            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${target.filter { it.isDigit() }.ifEmpty { "121" }}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            // Trigger Sensitive Confirmation
            pendingAction = PendingSensitiveAction(
                actionType = "CALL",
                target = target,
                details = "Phone Call to $target",
                executableIntent = dialIntent
            )

            return ToolResult(
                handled = true,
                feedbackMessage = "Boss, $target ko call dial kar doon? Confirm karne ke liye 'Haan' ya 'Bhej do' bolein.",
                actionExecuted = "PROMPT_CALL_CONFIRMATION",
                requiresConfirmation = true
            )
        }

        // 9. Communication: SMS / WhatsApp Message
        if (lower.contains("sms") || lower.contains("message") || lower.contains("msg")) {
            val target = extractTargetNameOrNumber(input, "message")
            val smsIntent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("sms:${target.filter { it.isDigit() }}")
                putExtra("sms_body", "Hello from ZOYA Assistant!")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            pendingAction = PendingSensitiveAction(
                actionType = "SMS",
                target = target,
                details = "Send SMS to $target",
                executableIntent = smsIntent
            )

            return ToolResult(
                handled = true,
                feedbackMessage = "Boss, $target ko message bhej doon? Confirm karne ke liye 'Haan' ya 'Bhej do' bolein.",
                actionExecuted = "PROMPT_SMS_CONFIRMATION",
                requiresConfirmation = true
            )
        }

        // 10. Web Search / YouTube Search
        if (lower.contains("search") || lower.contains("google karo") || lower.contains("internet par")) {
            val query = extractSearchQuery(input, "search")
            val searchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra(android.app.SearchManager.QUERY, query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return tryLaunchIntent(searchIntent, "Google Search par \"$query\" khol diya hai $title!", "WEB_SEARCH")
        }

        return ToolResult(handled = false)
    }

    private fun isAppLaunchCommand(lower: String): Boolean {
        return lower.contains("kholo") || lower.contains("open") || lower.contains("launch") || lower.contains("chalao") || lower.contains("start")
    }

    private suspend fun handleAppLaunch(
        lowerInput: String,
        title: String,
        protectedAppsManager: ProtectedAppsManager?
    ): ToolResult {
        val appPackages = mapOf(
            "youtube" to Pair("com.google.android.youtube", "YouTube"),
            "whatsapp" to Pair("com.whatsapp", "WhatsApp"),
            "camera" to Pair("android.media.action.IMAGE_CAPTURE", "Camera"),
            "gallery" to Pair("com.google.android.apps.photos", "Gallery & Photos"),
            "photos" to Pair("com.google.android.apps.photos", "Photos"),
            "calculator" to Pair("com.google.android.calculator", "Calculator"),
            "settings" to Pair("android.settings.SETTINGS", "System Settings"),
            "chrome" to Pair("com.android.chrome", "Google Chrome"),
            "browser" to Pair("com.android.chrome", "Browser"),
            "instagram" to Pair("com.instagram.android", "Instagram"),
            "facebook" to Pair("com.facebook.katana", "Facebook"),
            "maps" to Pair("com.google.android.apps.maps", "Google Maps"),
            "vault" to Pair("com.hidden.vault", "Private Vault")
        )

        for ((key, targetPair) in appPackages) {
            if (lowerInput.contains(key)) {
                val target = targetPair.first
                val appName = targetPair.second

                // Protected App Check
                if (protectedAppsManager != null) {
                    val isLocked = protectedAppsManager.isAppProtected(target)
                    if (isLocked) {
                        return ToolResult(
                            handled = true,
                            feedbackMessage = "Boss, '$appName' aapne protected rakha hai. Main ise open nahi karungi.",
                            actionExecuted = "BLOCKED_PROTECTED_APP"
                        )
                    }
                }

                // Update follow-up context
                if (key == "youtube") currentContextApp = "YOUTUBE"
                if (key == "whatsapp") currentContextApp = "WHATSAPP"

                // System actions
                if (key == "camera") {
                    val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                    return tryLaunchIntent(intent, "Camera open kar diya hai $title!", "LAUNCH_CAMERA")
                }
                if (key == "calculator") {
                    val intent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_APP_CALCULATOR)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    return tryLaunchIntent(intent, "Calculator khol diya hai $title!", "LAUNCH_CALCULATOR")
                }
                if (key == "settings") {
                    val intent = Intent(Settings.ACTION_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                    return tryLaunchIntent(intent, "Settings open kar diye hain $title!", "LAUNCH_SETTINGS")
                }

                // Package launch
                val launchIntent = context.packageManager.getLaunchIntentForPackage(target)
                return if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    tryLaunchIntent(launchIntent, "$appName open kar diya hai $title!", "LAUNCH_APP_$appName")
                } else {
                    // Fallback to browser or Play Store
                    val playIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$target")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    tryLaunchIntent(playIntent, "$appName installed nahi hai $title! Play Store khol diya hai.", "LAUNCH_PLAY_STORE")
                }
            }
        }

        return ToolResult(handled = false)
    }

    private fun executePendingAction(pending: PendingSensitiveAction, title: String): ToolResult {
        return if (pending.executableIntent != null) {
            tryLaunchIntent(
                intent = pending.executableIntent,
                successMsg = "Ji $title! $pending.actionType trigger kar diya hai.",
                actionName = "EXECUTE_CONFIRMED_${pending.actionType}"
            )
        } else {
            ToolResult(
                handled = true,
                feedbackMessage = "Ji $title! Action complete ho gaya hai.",
                actionExecuted = "EXECUTE_CONFIRMED"
            )
        }
    }

    private fun tryLaunchIntent(intent: Intent, successMsg: String, actionName: String): ToolResult {
        return try {
            context.startActivity(intent)
            ToolResult(handled = true, feedbackMessage = successMsg, actionExecuted = actionName)
        } catch (e: SecurityException) {
            val settingsIntent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try { context.startActivity(settingsIntent) } catch (_: Exception) {}
            ToolResult(
                handled = true,
                feedbackMessage = "Boss, is action ke liye missing Android permission chahiye! Permissions setting open kar di hai.",
                actionExecuted = "PERMISSION_ERROR_SETTINGS"
            )
        } catch (e: Exception) {
            ToolResult(
                handled = true,
                feedbackMessage = "Action launch error: ${e.localizedMessage ?: "Unknown failure"}",
                actionExecuted = "LAUNCH_FAILED"
            )
        }
    }

    private fun getBatteryLevel(): String {
        return try {
            val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { filter ->
                context.registerReceiver(null, filter)
            }
            val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val pct = (level * 100 / scale.toFloat()).toInt()
            "$pct%"
        } catch (e: Exception) {
            "Unknown"
        }
    }

    private fun isConfirmationYes(lower: String): Boolean {
        return lower.contains("haan") || lower.contains("yes") || lower.contains("bhej do") || lower.contains("karo") || lower.contains("confirm") || lower.contains("sahi hai")
    }

    private fun isConfirmationNo(lower: String): Boolean {
        return lower.contains("nahi") || lower.contains("no") || lower.contains("cancel") || lower.contains("mat karo") || lower.contains("rehne do")
    }

    private fun extractTargetNameOrNumber(input: String, actionWord: String): String {
        return input.replace("zoya", "", ignoreCase = true)
            .replace(actionWord, "", ignoreCase = true)
            .replace("karo", "", ignoreCase = true)
            .replace("karna", "", ignoreCase = true)
            .replace("bhejo", "", ignoreCase = true)
            .replace("ko", "", ignoreCase = true)
            .replace("par", "", ignoreCase = true)
            .trim()
            .ifEmpty { "Mummy" }
    }

    private fun extractSearchQuery(input: String, type: String): String {
        return input.replace("zoya", "", ignoreCase = true)
            .replace("search", "", ignoreCase = true)
            .replace("google karo", "", ignoreCase = true)
            .replace("karo", "", ignoreCase = true)
            .replace("internet par", "", ignoreCase = true)
            .replace("youtube par", "", ignoreCase = true)
            .replace("chalao", "", ignoreCase = true)
            .replace("ab", "", ignoreCase = true)
            .trim()
            .ifEmpty { "Latest trending videos" }
    }
}
