package com.example.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity

class GreetingReceiver : BroadcastReceiver() {

    companion object {
        const val CHANNEL_ID = "ZOYA_GREETING_CHANNEL"
        const val EXTRA_GREETING_TYPE = "EXTRA_GREETING_TYPE" // "MORNING" or "NIGHT"

        fun createMorningIntent(context: Context): Intent {
            return Intent(context, GreetingReceiver::class.java).apply {
                putExtra(EXTRA_GREETING_TYPE, "MORNING")
            }
        }

        fun createNightIntent(context: Context): Intent {
            return Intent(context, GreetingReceiver::class.java).apply {
                putExtra(EXTRA_GREETING_TYPE, "NIGHT")
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        val type = intent.getStringExtra(EXTRA_GREETING_TYPE) ?: "MORNING"

        val title: String
        val message: String

        if (type == "MORNING") {
            title = "Good Morning Sonu Boss! ☀️"
            message = "Good morning Sonu Boss ☀️ Utho Boss, aaj ka din shuru karte hain 😎"
        } else {
            title = "Good Night Sonu Boss! 🌙"
            message = "Good night Sonu Boss 🌙 Ab rest karo Boss. Kal phir milkar dhamaka karenge 😂"
        }

        showGreetingNotification(context, title, message)
    }

    private fun showGreetingNotification(context: Context, title: String, message: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "ZOYA Morning & Night Greetings",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Daily morning and night greetings from ZOYA Assistant"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val pendingIntent = Intent(context, MainActivity::class.java).let { mainIntent ->
            PendingIntent.getActivity(
                context, 0, mainIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        notificationManager.notify(if (title.contains("Morning")) 2001 else 2002, notification)
    }
}
