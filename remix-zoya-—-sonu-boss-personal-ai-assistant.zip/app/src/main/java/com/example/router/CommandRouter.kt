package com.example.router

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.speech.RecognizerIntent
import android.util.Log

data class CommandResult(
    val handled: Boolean,
    val feedbackMessage: String? = null,
    val actionExecuted: String? = null
)

object CommandRouter {

    suspend fun executeCommand(
        context: Context,
        input: String,
        userName: String,
        title: String,
        protectedAppsManager: com.example.privacy.ProtectedAppsManager? = null
    ): CommandResult {
        val lower = input.lowercase().trim()

        // 1. App Launching Commands ("youtube kholo", "open whatsapp", etc.)
        if (lower.contains("kholo") || lower.contains("open") || lower.contains("launch")) {
            val appResult = handleAppLaunch(context, lower, title, protectedAppsManager)
            if (appResult.handled) return appResult
        }

        // 2. Battery / System Status Commands
        if (lower.contains("battery") || lower.contains("charge") || lower.contains("charging")) {
            val batteryStatus = getBatteryStatus(context)
            return CommandResult(
                handled = true,
                feedbackMessage = "Ji $userName $title! $batteryStatus",
                actionExecuted = "SYSTEM_BATTERY_CHECK"
            )
        }

        // 3. Web Search Commands ("search", "google karo", "internet par search")
        if (lower.contains("search karo") || lower.contains("google karo") || lower.contains("internet par search")) {
            val searchQuery = extractSearchQuery(input)
            val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra(android.app.SearchManager.QUERY, searchQuery)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return try {
                context.startActivity(intent)
                CommandResult(
                    handled = true,
                    feedbackMessage = "Google search results khol diye hain $title! Query: \"$searchQuery\"",
                    actionExecuted = "WEB_SEARCH"
                )
            } catch (e: Exception) {
                val browserIntent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/search?q=${Uri.encode(searchQuery)}")
                ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                context.startActivity(browserIntent)
                CommandResult(
                    handled = true,
                    feedbackMessage = "Browser mein search results khol diye hain $title!",
                    actionExecuted = "WEB_SEARCH_BROWSER"
                )
            }
        }

        // 4. Phone Calls / Dialing Commands ("call karo", "ko call karna")
        if (lower.contains("call") || lower.contains("dial") || lower.contains("phone karo")) {
            val target = extractCallTarget(input)
            val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:${target.filter { it.isDigit() }}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return try {
                context.startActivity(dialIntent)
                CommandResult(
                    handled = true,
                    feedbackMessage = "Dialer screen open kar di hai $title! Contact: $target",
                    actionExecuted = "DIALER_LAUNCH"
                )
            } catch (e: Exception) {
                CommandResult(
                    handled = true,
                    feedbackMessage = "Dialer open nahi ho paya, Boss!",
                    actionExecuted = "DIALER_FAILED"
                )
            }
        }

        // Unrecognized system command -> Route to Gemini AI
        return CommandResult(handled = false)
    }

    private suspend fun handleAppLaunch(
        context: Context,
        lowerInput: String,
        title: String,
        protectedAppsManager: com.example.privacy.ProtectedAppsManager?
    ): CommandResult {
        val appPackages = mapOf(
            "youtube" to Pair("com.google.android.youtube", "YouTube"),
            "whatsapp" to Pair("com.whatsapp", "WhatsApp"),
            "chrome" to Pair("com.android.chrome", "Google Chrome"),
            "camera" to Pair("android.media.action.IMAGE_CAPTURE", "Camera"),
            "maps" to Pair("com.google.android.apps.maps", "Google Maps"),
            "settings" to Pair("android.settings.SETTINGS", "System Settings"),
            "gallery" to Pair("com.google.android.apps.photos", "Photos / Gallery"),
            "vault" to Pair("com.hidden.vault", "Private Vault"),
            "photos" to Pair("com.google.android.apps.photos", "Photos")
        )

        for ((key, targetPair) in appPackages) {
            if (lowerInput.contains(key)) {
                val target = targetPair.first
                val appName = targetPair.second

                // Protected App Check
                if (protectedAppsManager != null) {
                    val isLocked = protectedAppsManager.isAppProtected(target)
                    if (isLocked) {
                        return CommandResult(
                            handled = true,
                            feedbackMessage = "Boss, ye app aapne protected rakha hai. Main ise open nahi karungi.",
                            actionExecuted = "BLOCKED_PROTECTED_APP"
                        )
                    }
                }

                // Special system intents
                if (key == "camera") {
                    val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    return try {
                        context.startActivity(intent)
                        CommandResult(true, "Camera open kar diya hai $title!", "LAUNCH_CAMERA")
                    } catch (e: Exception) {
                        CommandResult(true, "Camera launch error: ${e.localizedMessage}", "LAUNCH_FAILED")
                    }
                } else if (key == "settings") {
                    val intent = Intent(android.provider.Settings.ACTION_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    return try {
                        context.startActivity(intent)
                        CommandResult(true, "Settings open kar diye hain $title!", "LAUNCH_SETTINGS")
                    } catch (e: Exception) {
                        CommandResult(true, "Settings launch error", "LAUNCH_FAILED")
                    }
                }

                // App Package launch
                val launchIntent = context.packageManager.getLaunchIntentForPackage(target)
                return if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    CommandResult(true, "$appName open kar diya hai $title!", "LAUNCH_$key")
                } else {
                    // Open in web or store if app package not installed
                    val webIntent = Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://www.google.com/search?q=$appName")
                    ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                    context.startActivity(webIntent)
                    CommandResult(
                        true,
                        "$appName app nahi mili, browser mein khol diya hai $title!",
                        "LAUNCH_WEB_$key"
                    )
                }
            }
        }

        return CommandResult(handled = false)
    }

    private fun getBatteryStatus(context: Context): String {
        return try {
            val intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus: Intent? = context.registerReceiver(null, intentFilter)

            val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale.toFloat()).toInt() else 100

            val status: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL

            val chargeStateStr = if (isCharging) "aur phone charging par hai!" else "aur battery normal level par hai."
            "Aapka phone $batteryPct% charged hai $chargeStateStr"
        } catch (e: Exception) {
            "Aapka system green hai aur battery operating range mein hai, Boss!"
        }
    }

    private fun extractSearchQuery(input: String): String {
        return input.replace("search karo", "", ignoreCase = true)
            .replace("google karo", "", ignoreCase = true)
            .replace("internet par search", "", ignoreCase = true)
            .replace("zoya", "", ignoreCase = true)
            .trim()
            .ifBlank { "Latest tech news" }
    }

    private fun extractCallTarget(input: String): String {
        return input.replace("call karo", "", ignoreCase = true)
            .replace("call karna", "", ignoreCase = true)
            .replace("ko call", "", ignoreCase = true)
            .replace("zoya", "", ignoreCase = true)
            .trim()
            .ifBlank { "Mom" }
    }
}
