package com.example.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fact: String,
    val category: String = "General",
    val timestamp: Long = System.currentTimeMillis()
)
