package com.example.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PersonDao {
    @Query("SELECT * FROM people ORDER BY name ASC")
    fun getAllPeople(): Flow<List<PersonEntity>>

    @Query("SELECT * FROM people WHERE LOWER(relationship) = LOWER(:relationship) LIMIT 1")
    suspend fun getPersonByRelationship(relationship: String): PersonEntity?

    @Query("SELECT * FROM people WHERE LOWER(name) LIKE '%' || LOWER(:query) || '%' OR LOWER(relationship) LIKE '%' || LOWER(:query) || '%' LIMIT 1")
    suspend fun findPerson(query: String): PersonEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPerson(person: PersonEntity): Long

    @Update
    suspend fun updatePerson(person: PersonEntity)

    @Delete
    suspend fun deletePerson(person: PersonEntity)

    @Query("DELETE FROM people WHERE id = :id")
    suspend fun deletePersonById(id: Int)
}
