package com.example.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [PersonEntity::class, MemoryEntity::class, ProtectedAppEntity::class],
    version = 1,
    exportSchema = false
)
abstract class ZoyaDatabase : RoomDatabase() {

    abstract fun personDao(): PersonDao
    abstract fun memoryDao(): MemoryDao
    abstract fun protectedAppDao(): ProtectedAppDao

    companion object {
        @Volatile
        private var INSTANCE: ZoyaDatabase? = null

        fun getInstance(context: Context): ZoyaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ZoyaDatabase::class.java,
                    "zoya_assistant_db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
