package com.example.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProtectedAppDao {
    @Query("SELECT * FROM protected_apps ORDER BY appName ASC")
    fun getAllProtectedApps(): Flow<List<ProtectedAppEntity>>

    @Query("SELECT * FROM protected_apps WHERE packageName = :packageName LIMIT 1")
    suspend fun getProtectedApp(packageName: String): ProtectedAppEntity?

    @Query("SELECT EXISTS(SELECT 1 FROM protected_apps WHERE packageName = :packageName AND isLocked = 1)")
    suspend fun isAppProtected(packageName: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProtectedApp(app: ProtectedAppEntity)

    @Update
    suspend fun updateProtectedApp(app: ProtectedAppEntity)

    @Delete
    suspend fun deleteProtectedApp(app: ProtectedAppEntity)

    @Query("DELETE FROM protected_apps WHERE packageName = :packageName")
    suspend fun deleteByPackageName(packageName: String)
}
