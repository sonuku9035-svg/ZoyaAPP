package com.example.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "people")
data class PersonEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val relationship: String, // Mummy, Bhaiya, Bhabhi, Papa, Son, Friend, etc.
    val nickname: String = "",
    val phoneNumber: String = "",
    val email: String = "",
    val optionalNotes: String = "",
    val optionalVoiceProfileHash: String = "", // Voice profile enrollment hash/token
    val updatedAt: Long = System.currentTimeMillis()
)
