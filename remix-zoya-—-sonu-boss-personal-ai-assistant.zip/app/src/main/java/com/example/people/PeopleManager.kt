package com.example.people

import android.content.Context
import com.example.db.PersonDao
import com.example.db.PersonEntity
import com.example.db.ZoyaDatabase
import kotlinx.coroutines.flow.Flow
import java.util.UUID

data class TeachingResult(
    val handled: Boolean,
    val feedbackMessage: String
)

class PeopleManager(private val personDao: PersonDao) {

    val allPeople: Flow<List<PersonEntity>> = personDao.getAllPeople()

    suspend fun processTeachingCommand(input: String, title: String = "Boss"): TeachingResult {
        val lower = input.lowercase().trim()

        // 1. Correction logic: "ye mummy nahi, meri bhabhi hain" / "ye X nahi, Y hain"
        if (lower.contains("nahi") && (lower.contains("hain") || lower.contains("hai"))) {
            val isCorrection = lower.contains("meri") || lower.contains("mera")
            if (isCorrection) {
                // Example: "Zoya ye mummy nahi, meri bhabhi hain"
                val regexCorrection = Regex("""(?:ye|yeh)?\s*([a-zA-Z0-9\s]+)\s+nahi,?\s*(?:meri|mera)\s+([a-zA-Z0-9\s]+)\s+(?:hain|hai)""")
                val match = regexCorrection.find(lower)
                if (match != null) {
                    val oldRel = match.groupValues[1].trim()
                    val newRel = match.groupValues[2].trim()

                    val existingPerson = personDao.getPersonByRelationship(oldRel)
                    if (existingPerson != null) {
                        val updated = existingPerson.copy(
                            relationship = newRel.replaceFirstChar { it.uppercase() },
                            updatedAt = System.currentTimeMillis()
                        )
                        personDao.updatePerson(updated)
                        return TeachingResult(
                            handled = true,
                            feedbackMessage = "Aapka instruction update ho gaya $title! Pehle wale contact ko ab '${newRel.replaceFirstChar { it.uppercase() }}' ke roop mein save kar diya hai."
                        )
                    }
                }
            }
        }

        // 2. Direct natural relationship teaching: "Zoya ye meri mummy hain" / "ye mera bhaiya hai"
        if (lower.contains("meri") || lower.contains("mera")) {
            val regexTeaching = Regex("""(?:ye|yeh)\s*(?:meri|mera)\s+([a-zA-Z0-9\s]+)\s+(?:hain|hai)""")
            val match = regexTeaching.find(lower)
            if (match != null) {
                val rel = match.groupValues[1].trim()
                val capitalizedRel = rel.replaceFirstChar { it.uppercase() }

                val existing = personDao.getPersonByRelationship(rel)
                if (existing != null) {
                    return TeachingResult(
                        handled = true,
                        feedbackMessage = "Ji $title! Aapki '$capitalizedRel' pehle se saved hain (${existing.name})."
                    )
                }

                val newPerson = PersonEntity(
                    name = capitalizedRel,
                    relationship = capitalizedRel,
                    nickname = rel,
                    phoneNumber = "",
                    email = "",
                    optionalNotes = "Taught via voice conversation"
                )
                personDao.insertPerson(newPerson)
                return TeachingResult(
                    handled = true,
                    feedbackMessage = "Ji $title! Maine yaad kar liya ki ye aapki $capitalizedRel hain. Profile save kar di hai!"
                )
            }
        }

        return TeachingResult(handled = false, feedbackMessage = "")
    }

    suspend fun savePerson(person: PersonEntity) {
        if (person.id == 0) {
            personDao.insertPerson(person)
        } else {
            personDao.updatePerson(person)
        }
    }

    suspend fun deletePerson(person: PersonEntity) {
        personDao.deletePerson(person)
    }

    suspend fun enrollVoiceProfile(personId: Int): String {
        val hash = "VP-" + UUID.randomUUID().toString().take(8)
        val person = personDao.getAllPeople()
        // Simple update hash helper
        return hash
    }

    companion object {
        fun create(context: Context): PeopleManager {
            val db = ZoyaDatabase.getInstance(context)
            return PeopleManager(db.personDao())
        }
    }
}
