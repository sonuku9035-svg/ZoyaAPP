package com.example.model

enum class ZoyaState(val statusMessage: String) {
    IDLE("Ready, Boss"),
    LISTENING("Listening..."),
    THINKING("Thinking..."),
    WORKING("Working..."),
    SPEAKING("Speaking...")
}
